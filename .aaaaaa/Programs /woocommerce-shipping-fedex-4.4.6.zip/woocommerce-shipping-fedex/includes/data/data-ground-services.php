<?php
/**
 * FEDEX Ground services in array format.
 *
 * @package WC_Shipping_Fedex
 */

return array(
	'GROUND_HOME_DELIVERY',
	'FEDEX_GROUND',
	'INTERNATIONAL_GROUND',
);
