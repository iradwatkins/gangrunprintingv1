<?php

abstract class BWFCRM_Import_Export_Type {
	public static $IMPORT = 1;
	public static $EXPORT = 2;
}