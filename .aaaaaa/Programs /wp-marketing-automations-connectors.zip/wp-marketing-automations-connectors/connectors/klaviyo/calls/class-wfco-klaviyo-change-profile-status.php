<?php

namespace WFCO\Klaviyo;

#[\AllowDynamicProperties]
class Change_Profile_Status extends WFCO_Klaviyo_Call {

	private static $ins = null;
	private $api_params = [];
	private $action = null;

	public function __construct() {
		parent::__construct( [ 'api_key', 'list_id' ] );
	}

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	/**
	 * Get call slug
	 *
	 * @return string
	 */
	public function get_slug() {
		return 'wfco_klaviyo_change_profile_status';
	}

	public function process_klaviyo_call() {
		if ( empty( $this->data['phone'] ) ) {
			$this->data['phone'] = isset( $this->data['profile_fields']['phone_number'] ) ? $this->data['profile_fields']['phone_number'] : '';
		}
		$params       = $this->get_subscribed_data();
		$this->action = isset( $this->data['action'] ) ? $this->data['action'] : '';
		if ( 'unsubscribe' === $this->action ) {
			$params = $this->get_unsubscribed_data();
		}
		/** If sms consent is disabled then unset the phone number */
		if ( 'unsubscribe' !== $this->action && empty( $this->data['sms_consent'] ) ) {
			if ( isset( $params['data']['attributes']['profiles']['data'][0]['attributes']['subscriptions']['sms'] ) ) {
				unset( $params['data']['attributes']['profiles']['data'][0]['attributes']['subscriptions']['sms'] );
			}
			if ( isset( $params['data']['attributes']['profiles']['data'][0]['attributes']['phone_number'] ) ) {
				unset( $params['data']['attributes']['profiles']['data'][0]['attributes']['phone_number'] );
			}
		}

		/** Handle Email consent */
		if ( 'unsubscribe' !== $this->action && empty( $this->data['email_consent'] ) ) {
			if ( isset( $params['data']['attributes']['profiles']['data'][0]['attributes']['subscriptions']['email'] ) ) {
				unset( $params['data']['attributes']['profiles']['data'][0]['attributes']['subscriptions']['email'] );
			}
			if ( isset( $params['data']['attributes']['profiles']['data'][0]['attributes']['email'] ) ) {
				unset( $params['data']['attributes']['profiles']['data'][0]['attributes']['email'] );
			}
		}

		if ( isset( $params['data']['attributes']['profiles']['data'][0]['id'] ) && empty( $params['data']['attributes']['profiles']['data'][0]['id'] ) ) {
			unset( $params['data']['attributes']['profiles']['data'][0]['id'] );
		}

		return $this->do_klaviyo_call( wp_json_encode( $params ), \BWF_CO::$POST );
	}

	private function get_subscribed_data() {
		$profile_data = [
			"type"       => "profile",
			"attributes" => [
				"subscriptions" => []
			]
		];

		// Add email subscription if consent given
		if ( ! empty( $this->data['email_consent'] ) ) {
			$profile_data['attributes']['email']                  = $this->data['email'];
			$profile_data['attributes']['subscriptions']['email'] = [
				"marketing" => [
					"consent" => "SUBSCRIBED"
				]
			];
		}

		// Add SMS subscription if consent given
		if ( ! empty( $this->data['sms_consent'] ) && ! empty( $this->data['phone'] ) ) {
			$profile_data['attributes']['phone_number']         = $this->data['phone'];
			$profile_data['attributes']['subscriptions']['sms'] = [
				"marketing"     => [
					"consent" => "SUBSCRIBED"
				],
				"transactional" => [
					"consent" => "SUBSCRIBED"
				]
			];
		}

		// Add profile ID if available
		if ( ! empty( $this->data['profile'] ) ) {
			$profile_data['id'] = $this->data['profile'];
		}

		return [
			"data" => [
				"type"          => "profile-subscription-bulk-create-job",
				"attributes"    => [
					"profiles"          => [
						"data" => [ $profile_data ]
					],
					"historical_import" => false
				],
				"relationships" => [
					"list" => [
						"data" => [
							"type" => "list",
							"id"   => $this->data['list_id']
						]
					]
				]
			]
		];
	}

	private function get_unsubscribed_data() {
		// Start with basic subscription structure
		$profile_attributes = [
			"type"       => "profile",
			"attributes" => [
				"email"         => $this->data['email'],
				"subscriptions" => [
					"email" => [
						"marketing" => [
							"consent" => "UNSUBSCRIBED"
						]
					]
				]
			]
		];

		// Only add phone and SMS data if phone number exists
		if ( ! empty( $this->data['phone'] ) ) {
			$profile_attributes['attributes']['phone_number']         = $this->data['phone'];
			$profile_attributes['attributes']['subscriptions']['sms'] = [
				"marketing"     => [
					"consent" => "UNSUBSCRIBED"
				],
				"transactional" => [
					"consent" => "UNSUBSCRIBED"
				]
			];
		}

		return [
			"data" => [
				"type"          => "profile-subscription-bulk-delete-job",
				"attributes"    => [
					"profiles" => [
						"data" => [ $profile_attributes ]
					]
				],
				"relationships" => [
					"list" => [
						"data" => [
							"type" => "list",
							"id"   => $this->data['list_id']
						]
					]
				]
			]
		];
	}


	/**
	 * Return the endpoint.
	 *
	 * @return string
	 */
	public function get_endpoint( $endpoint_var = '' ) {
		$url_endpoint = 'profile-subscription-bulk-create-jobs/';
		if ( 'unsubscribe' === $this->action ) {
			$url_endpoint = 'profile-subscription-bulk-delete-jobs/';
		}
		$url = \BWFCO_Klaviyo::$api_end_point . $url_endpoint;

		return add_query_arg( $this->api_params, $url );
	}

}

return 'WFCO\Klaviyo\Change_Profile_Status';
