<?php
$saved_data        = WFCO_Common::$connectors_saved_data;
$connector_class   = BWFCO_Bulkgate::get_instance();
$connector_slug    = $connector_class->get_slug();
$old_data          = ( isset( $saved_data[ $connector_slug ] ) && is_array( $saved_data[ $connector_slug ] ) && count( $saved_data[ $connector_slug ] ) > 0 ) ? $saved_data[ $connector_slug ] : array();
$application_id    = isset( $old_data['application_id'] ) ? $old_data['application_id'] : '';
$application_token = isset( $old_data['application_token'] ) ? $old_data['application_token'] : '';
$sender_id         = isset( $old_data['sender_id'] ) ? $old_data['sender_id'] : '';
?>

<div class="wfco-form-group featured field-input">
    <label for="automation-name"><?php echo esc_html__( 'Enter Application ID', 'wp-marketing-automations-connectors' ); ?></label>
    <div class="field-wrap">
        <div class="wrapper">
            <input type="text" name="application_id" placeholder="<?php echo esc_attr__( 'Enter Application ID', 'wp-marketing-automations-connectors' ); ?>" class="form-control wfco_bulkgate_application_id" required value="<?php echo esc_attr__( $application_id ); ?>">
        </div>
    </div>
</div>

<div class="wfco-form-group featured field-input">
    <label for="automation-name"><?php echo esc_html__( 'Enter Application Token', 'wp-marketing-automations-connectors' ) ?></label>
    <div class="field-wrap">
        <div class="wrapper">
            <input type="text" name="application_token" placeholder="<?php echo esc_html__( 'Enter Application Token', 'wp-marketing-automations-connectors' ) ?>" class="form-control wfco_bulkgate_application_token" required value="<?php echo esc_attr__( $application_token ); ?>">
        </div>
    </div>
</div>
<div class="wfco-form-group featured field-input">
    <label for="automation-name"><?php echo esc_html__( 'Sender ID', 'wp-marketing-automations-connectors' ) ?></label>
    <div class="field-wrap">
        <div class="wrapper">
            <input type="text" name="sender_id" placeholder="<?php echo esc_html__( 'Sender ID', 'wp-marketing-automations-connectors' ) ?>" class="form-control wfco_bulkgate_application_token" value="<?php echo esc_attr__( $application_token ); ?>">
        </div>
    </div>
</div>

<div class="wfco-form-groups wfco_form_submit wfco_bulkgate_main_submit">
	<?php
	if ( isset( $old_data['id'] ) && (int) $old_data['id'] > 0 ) {
		?>
        <input type="hidden" name="edit_nonce" value="<?php echo esc_attr__( wp_create_nonce( 'wfco-connector-edit' ) ); ?>"/>
        <input type="hidden" name="id" value="<?php echo esc_attr__( $old_data['id'] ); ?>"/>
        <input type="hidden" name="wfco_connector" value="<?php echo esc_attr__( $connector_slug ); ?>"/>
        <input type="submit" class="wfco_update_btn_style wfco_save_btn_style" name="autoresponderSubmit" value="<?php echo esc_attr__( 'Update', 'wp-marketing-automations-connectors' ); ?>">
	<?php } else { ?>
        <input type="hidden" name="_wpnonce" value="<?php echo esc_attr__( wp_create_nonce( 'wfco-connector' ) ); ?>">
        <input type="hidden" name="wfco_connector" value="<?php echo esc_attr__( $connector_slug ); ?>"/>
        <input type="submit" class="wfco_save_btn_style" name="autoresponderSubmit" value="<?php echo esc_attr__( 'Save', 'wp-marketing-automations-connectors' ); ?>">
	<?php } ?>
</div>
<div class="wfco_form_response" style=" text-align: center;font-size: 15px;margin-top: 10px;"></div>