<?php

namespace WFCO\MailerLite;

#[\AllowDynamicProperties]
class Get_Subscriber_Fields extends WFCO_Mailerlite_Call {

	private static $ins = null;

	public function __construct() {
		parent::__construct();
	}

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	/**
	 * Get call slug
	 *
	 * @return string
	 */
	public function get_slug() {
		return 'wfco_mailerlite_get_subscriber_fields';
	}

	public function process_mailerlite_call() {
		$params = [ 'bwfan_con_source' => 'autonami', 'method' => 'get' ];

		return $this->do_mailerlite_call( $params, \BWF_CO::$GET );
	}

	/**
	 * Return the endpoint.
	 *
	 * @return string
	 */
	public function get_endpoint( $endpoint_var = '' ) {
		return \BWFCO_Mailerlite::$api_end_point . 'fields';
	}

}

return 'WFCO\MailerLite\Get_Subscriber_Fields';
