<?php

namespace WFCO\WebinarJam;

#[\AllowDynamicProperties]
class Get_Schedules extends \WFCO_Call {
	private static $instance = null;
	private $api_end_point = null;

	public function __construct() {
		$this->required_fields = array( 'api_key', 'webinar_id' );
		$this->api_end_point   = 'https://api.webinarjam.com/webinarjam/webinar';
	}

	/**
	 * @return Get_Schedules|null
	 */

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Get call slug
	 *
	 * @return string
	 */
	public function get_slug() {
		return 'wfco_webinarjam_get_schedules';
	}

	/**
	 * Process and do the actual processing for the current action.
	 * This function is present in every action class.
	 */
	public function process() {
		$is_required_fields_present = $this->check_fields( $this->data, $this->required_fields );
		if ( false === $is_required_fields_present ) {
			return $this->show_fields_error();
		}

		$params = array(
			'api_key'    => $this->data['api_key'],
			'webinar_id' => $this->data['webinar_id']
		);

		$res = $this->make_wp_requests( $this->api_end_point, $params, array(), \BWF_CO::$POST );

		return $res;
	}

}

return 'WFCO\WebinarJam\Get_Schedules';
