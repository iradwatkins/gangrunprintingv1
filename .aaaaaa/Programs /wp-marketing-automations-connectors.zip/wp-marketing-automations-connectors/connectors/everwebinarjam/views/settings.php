<?php
$saved_data      = WFCO_Common::$connectors_saved_data;
$connector_class = BWFCO_Ever_WebinarJam::get_instance();
$old_data        = ( isset( $saved_data[ $connector_class->get_slug() ] ) && is_array( $saved_data[ $connector_class->get_slug() ] ) && count( $saved_data[ $connector_class->get_slug() ] ) > 0 ) ? $saved_data[ $connector_class->get_slug() ] : array();
$api_key         = isset( $old_data['$api_key'] ) ? $old_data['$api_key'] : '';
?>
<div class="wfco-webinarjam-wrap">
    <div class="wfco-form-group featured field-input">
        <label for="automation-name"><?php echo esc_html__( 'Enter API Key', 'wp-marketing-automations-connectors' ); ?></label>
        <div class="field-wrap">
            <div class="wrapper">
                <input type="text" name="api_key" placeholder="<?php echo esc_attr__( 'Enter API Key', 'wp-marketing-automations-connectors' ); ?>" class="form-control wfco_webinarjam_api_key" required value="<?php echo esc_attr__( $api_key ); ?>">
            </div>
        </div>
    </div>

    <div class="wfco-form-groups wfco_form_submit">
		<?php
		if ( isset( $old_data['id'] ) && (int) $old_data['id'] > 0 ) {
			?>
            <input type="hidden" name="edit_nonce" value="<?php echo esc_attr__( wp_create_nonce( 'wfco-connector-edit' ) ); ?>"/>
            <input type="hidden" name="id" value="<?php echo esc_attr__( $old_data['id'] ); ?>"/>
            <input type="hidden" name="wfco_connector" value="<?php echo esc_attr__( $connector_class->get_slug() ); ?>"/>
            <button class="wfco_save_btn_style wfco_connect_to_api"><?php esc_attr_e( 'Connect and Update', 'wp-marketing-automations-connectors' ); ?></button>
		<?php } else { ?>
            <input type="hidden" name="_wpnonce" value="<?php echo esc_attr__( wp_create_nonce( 'wfco-connector' ) ); ?>">
            <input type="hidden" name="wfco_connector" value="<?php echo esc_attr__( $connector_class->get_slug() ); ?>"/>
            <button class="wfco_save_btn_style wfco_connect_to_api"><?php esc_attr_e( 'Connect and Save', 'wp-marketing-automations-connectors' ); ?></button>
		<?php } ?>
    </div>
    <div class="wfco_form_response" style="text-align: center;font-size: 15px;margin-top: 10px;"></div>
</div>
