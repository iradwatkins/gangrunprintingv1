<?php

namespace WFCO\AC;
if ( ! class_exists( 'Delete_Pipeline' ) ) {
	#[\AllowDynamicProperties]
	class Delete_Pipeline extends \WFCO_Call {

		private static $instance = null;

		public function __construct() {
			$this->required_fields = array( 'api_key', 'api_url', 'pipeline_id' );
		}

		public static function get_instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Get call slug
		 *
		 * @return string
		 */
		public function get_slug() {
			return 'wfco_ac_delete_pipeline';
		}

		/**
		 * Process and do the actual processing for the current action.
		 * This function is present in every action class.
		 */
		public function process() {
			$is_required_fields_present = $this->check_fields( $this->data, $this->required_fields );
			if ( false === $is_required_fields_present ) {
				return $this->show_fields_error();
			}

			\BWFCO_ActiveCampaign::set_headers( $this->data['api_key'] );

			return $this->delete_pipeline();
		}

		/**
		 * Delete pipeline
		 *
		 * @return array|mixed|object|string
		 */
		public function delete_pipeline() {
			$api_action   = 'dealGroups';
			$params_data  = [];
			$endpoint_url = \BWFCO_ActiveCampaign::get_endpoint_url( $this->data['api_url'], $api_action );
			$endpoint_url = $endpoint_url . '/' . $this->data['pipeline_id'];
			$result       = $this->make_wp_requests( $endpoint_url, $params_data, \BWFCO_ActiveCampaign::get_headers(), \BWF_CO::$DELETE );

			return $result;
		}

	}

	return 'WFCO\\AC\\Delete_Pipeline';
}