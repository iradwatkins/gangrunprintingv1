<?php

namespace WFCO\AC;
if ( ! class_exists( 'Create_Stage' ) ) {
	#[\AllowDynamicProperties]
	class Create_Stage extends \WFCO_Call {

		private static $instance = null;

		public function __construct() {
			$this->required_fields = array( 'api_key', 'api_url', 'title', 'pipeline_id' );
		}

		public static function get_instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Get call slug
		 *
		 * @return string
		 */
		public function get_slug() {
			return 'wfco_ac_create_stage';
		}

		/**
		 * Process and do the actual processing for the current action.
		 * This function is present in every action class.
		 */
		public function process() {
			$is_required_fields_present = $this->check_fields( $this->data, $this->required_fields );
			if ( false === $is_required_fields_present ) {
				return $this->show_fields_error();
			}

			\BWFCO_ActiveCampaign::set_headers( $this->data['api_key'] );

			return $this->create_stage();
		}

		/**
		 * Create a stage.
		 *
		 * @return array|mixed|object|string
		 */
		public function create_stage() {
			$api_action  = 'dealStages';
			$params_data = array(
				'dealStage' => array(
					'title' => $this->data['title'],
					'group' => $this->data['pipeline_id'],
				),
			);

			$params_data  = wp_json_encode( $params_data );
			$endpoint_url = \BWFCO_ActiveCampaign::get_endpoint_url( $this->data['api_url'], $api_action );
			$result       = $this->make_wp_requests( $endpoint_url, $params_data, \BWFCO_ActiveCampaign::get_headers(), \BWF_CO::$POST );

			return $result;
		}

	}

	return 'WFCO\\AC\\Create_Stage';
}