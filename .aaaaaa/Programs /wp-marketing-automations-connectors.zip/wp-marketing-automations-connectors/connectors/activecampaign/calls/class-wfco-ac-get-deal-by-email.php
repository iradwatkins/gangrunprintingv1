<?php

namespace WFCO\AC;
if ( ! class_exists( 'Get_Deal_By_Email' ) ) {
	#[\AllowDynamicProperties]
	class Get_Deal_By_Email extends \WFCO_Call {

		private static $instance = null;

		public function __construct() {
			$this->required_fields = array( 'api_key', 'api_url', 'email' );
		}

		public static function get_instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Get call slug
		 *
		 * @return string
		 */
		public function get_slug() {
			return 'wfco_ac_get_deal_by_email';
		}

		/**
		 * Process and do the actual processing for the current action.
		 * This function is present in every action class.
		 */
		public function process() {
			$is_required_fields_present = $this->check_fields( $this->data, $this->required_fields );
			if ( false === $is_required_fields_present ) {
				return $this->show_fields_error();
			}

			\BWFCO_ActiveCampaign::set_headers( $this->data['api_key'] );

			return $this->get_deals();
		}

		/**
		 * View multiple mailing lists.
		 *
		 * @return array
		 */
		public function get_deals() {
			$api_action  = 'deals';
			$params_data = array(
				'limit'  => 1,
				'offset' => 0,
			);

			$endpoint_url = \BWFCO_ActiveCampaign::get_endpoint_url( $this->data['api_url'], $api_action );
			$endpoint_url = add_query_arg( array( 'filters[search]' => $this->data['email'], 'orders[cdate]' => 'desc' ), $endpoint_url );
			if ( isset( $this->data['pipeline_id'] ) && ! empty( $this->data['pipeline_id'] ) ) {
				$endpoint_url = add_query_arg( array( 'filters[group]' => $this->data['pipeline_id'] ), $endpoint_url );
			}

			$result = $this->make_wp_requests( $endpoint_url, $params_data, \BWFCO_ActiveCampaign::get_headers(), \BWF_CO::$GET );

			return $result;

		}

	}

	return 'WFCO\\AC\\Get_Deal_By_Email';
}