<?php
if ( ! class_exists( 'BWFAN_AC_Create_Contact' ) ) {
	#[AllowDynamicProperties]
	final class BWFAN_AC_Create_Contact extends BWFAN_Action {

		private static $instance = null;

		private function __construct() {
			$this->action_name     = __( 'Create Contact', 'wp-marketing-automations-connectors' );
			$this->action_desc     = __( 'This action creates a contact', 'wp-marketing-automations-connectors' );
			$this->action_priority = 15;
			$this->support_v2      = true;
		}

		public static function get_instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function get_view() {
			$unique_slug = $this->get_slug();
			?>
            <script type="text/html" id="tmpl-action-<?php echo esc_attr__( $unique_slug ); ?>">
                <#
                selected_first_name = (_.has(data.actionSavedData, 'data') && _.has(data.actionSavedData.data, 'first_name')) ? data.actionSavedData.data.first_name : '';
                selected_last_name = (_.has(data.actionSavedData, 'data') && _.has(data.actionSavedData.data, 'last_name')) ? data.actionSavedData.data.last_name : '';
                selected_email = (_.has(data.actionSavedData, 'data') && _.has(data.actionSavedData.data, 'email')) ? data.actionSavedData.data.email : '';
                #>

                <label for="" class="bwfan-label-title">
					<?php esc_html_e( 'Email', 'wp-marketing-automations-connectors' ); ?>
					<?php echo $this->inline_merge_tag_invoke(); //phpcs:ignore WordPress.Security.EscapeOutput ?>
                </label>
                <div class="bwfan-col-sm-12 bwfan-pl-0 bwfan-pr-0 bwfan-mb-15">
                    <input required type="text" class="bwfan-input-wrapper bwfan-field-<?php esc_html_e( $unique_slug ); ?>" name="bwfan[{{data.action_id}}][data][email]" placeholder="Email" value="{{selected_email}}"/>
                </div>
                <label for="" class="bwfan-label-title">
					<?php esc_html_e( 'First Name (optional)', 'wp-marketing-automations-connectors' ); ?>
					<?php echo $this->inline_merge_tag_invoke(); //phpcs:ignore WordPress.Security.EscapeOutput ?>
                </label>
                <div class="bwfan-col-sm-12 bwfan-pl-0 bwfan-pr-0 bwfan-mb-15">
                    <input required type="text" class="bwfan-input-wrapper bwfan-field-<?php esc_html_e( $unique_slug ); ?>" name="bwfan[{{data.action_id}}][data][first_name]" placeholder="First Name" value="{{selected_first_name}}"/>
                </div>
                <label for="" class="bwfan-label-title">
					<?php esc_html_e( 'Last Name (optional)', 'wp-marketing-automations-connectors' ); ?>
					<?php echo $this->inline_merge_tag_invoke(); //phpcs:ignore WordPress.Security.EscapeOutput ?>
                </label>
                <div class="bwfan-col-sm-12 bwfan-pl-0 bwfan-pr-0 bwfan-mb-15">
                    <input required type="text" class="bwfan-input-wrapper bwfan-field-<?php esc_html_e( $unique_slug ); ?>" name="bwfan[{{data.action_id}}][data][last_name]" placeholder="Last Name" value="{{selected_last_name}}"/>
                </div>
            </script>
			<?php
		}

		/**
		 * Make all the data which is required by the current action.
		 * This data will be used while executing the task of this action.
		 *
		 * @param $integration_object BWFAN_Integration
		 * @param $task_meta
		 *
		 * @return array|void
		 */
		public function make_data( $integration_object, $task_meta ) {
			$data_to_set               = array();
			$data_to_set['api_key']    = $integration_object->get_settings( 'api_key' );
			$data_to_set['api_url']    = $integration_object->get_settings( 'api_url' );
			$data_to_set['first_name'] = BWFAN_Common::decode_merge_tags( $task_meta['data']['first_name'] );
			$data_to_set['last_name']  = BWFAN_Common::decode_merge_tags( $task_meta['data']['last_name'] );
			$data_to_set['email']      = BWFAN_Common::decode_merge_tags( $task_meta['data']['email'] );

			return $data_to_set;
		}

		public function make_v2_data( $automation_data, $step_data ) {
			$data_to_set               = array();
			$data_to_set['api_key']    = isset( $step_data['connector_data']['api_key'] ) ? $step_data['connector_data']['api_key'] : '';
			$data_to_set['api_url']    = isset( $step_data['connector_data']['api_url'] ) ? $step_data['connector_data']['api_url'] : '';
			$data_to_set['first_name'] = BWFAN_Common::decode_merge_tags( $step_data['first_name'] );
			$data_to_set['last_name']  = BWFAN_Common::decode_merge_tags( $step_data['last_name'] );
			$data_to_set['email']      = BWFAN_Common::decode_merge_tags( $step_data['email'] );

			return $data_to_set;
		}

		protected function handle_response( $result, $call_object = null ) {
			if ( isset( $result['status'] ) ) {
				return $result;
			}

			if ( isset( $result['body']['contact'] ) && isset( $result['body']['contact']['id'] ) && ! empty( $result['body']['contact']['id'] ) ) {
				return array(
					'status'  => 3,
					'message' => isset( $result['body']['result_message'] ) ? $result['body']['result_message'] : __( 'Contact created successfully!', 'wp-marketing-automations-connectors' ),
				);
			}

			if ( 502 === absint( $result['response'] ) && is_array( $result['body'] ) ) {
				return array(
					'status'  => 4,
					'message' => isset( $result['body'][0] ) ? $result['body'][0] : __( 'Unknown FunnelKit Automations Error', 'wp-marketing-automations-connectors' ),
				);
			}

			if ( is_array( $result['body'] ) && isset( $result['body']['errors'] ) ) {
				return array(
					'status'  => 4,
					'message' => sprintf( __( 'Error: %s', 'wp-marketing-automations-connectors' ), $result['body']['errors'][0]['title'] ),
				);
			}

			$response_code   = __( '. Response Code: ', 'wp-marketing-automations-connectors' ) . $result['response'];
			$result_message  = ( is_array( $result['body'] ) && isset( $result['body']['result_message'] ) ) ? $result['body']['result_message'] : false;
			$message         = ( is_array( $result['body'] ) && isset( $result['body']['message'] ) ) ? $result['body']['message'] : false;
			$unknown_message = __( 'Unknown API Exception', 'wp-marketing-automations-connectors' );

			return array(
				'status'  => 4,
				'message' => ( false !== $result_message ? $result_message : ( false !== $message ? $message : $unknown_message ) ) . $response_code,
			);
		}

		public function handle_response_v2( $result ) {
			$message = __( 'Unknown Error', 'wp-marketing-automations-connectors' );

			/** check if the status is set 3 then return success message */
			if ( ! isset( $result['response'] ) && isset( $result['status'] ) && 3 === absint( $result['status'] ) ) {
				return $this->success_message( $result['message'] );
			}

			if ( ! isset( $result['response'] ) ) {
				return $this->error_response( $message );
			}

			if ( 502 === absint( $result['response'] ) && is_array( $result['body'] ) ) {
				$message = isset( $result['body'][0] ) ? $result['body'][0] : __( 'Unknown FunnelKit Automations Error', 'wp-marketing-automations-connectors' );
			}

			if ( is_array( $result['body'] ) && isset( $result['body']['errors'] ) ) {
				$message = __( 'Error: ' . $result['body']['errors'][0]['title'], 'wp-marketing-automations-connectors' );
			}

			if ( 200 !== $result['response'] ) {
				return $this->error_response( $message );
			}

			$response_code   = __( '. Response Code: ', 'wp-marketing-automations-connectors' ) . $result['response'];
			$result_message  = ( is_array( $result['body'] ) && isset( $result['body']['result_message'] ) ) ? $result['body']['result_message'] : false;
			$message         = ( is_array( $result['body'] ) && isset( $result['body']['message'] ) ) ? $result['body']['message'] : false;
			$unknown_message = __( 'Unknown API Exception', 'wp-marketing-automations-connectors' );

			return $this->success_message( ( false !== $result_message ? $result_message : ( false !== $message ? $message : $unknown_message ) ) . $response_code );
		}

		/**
		 * v2 Method: Get field Schema
		 *
		 * @return array[]
		 */
		public function get_fields_schema() {

			return [
				[
					'id'          => 'email',
					'label'       => __( "Email", 'wp-marketing-automations-connectors' ),
					'type'        => 'text',
					'placeholder' => __( "Email", 'wp-marketing-automations-connectors' ),
					"class"       => 'bwfan-input-wrapper',
					'tip'         => '',
					"description" => '',
					"required"    => true,
					"errorMsg"    => __( "Email is required", 'wp-marketing-automations-connectors' ),
				],
				[
					'id'          => 'first_name',
					'label'       => __( "First Name", 'wp-marketing-automations-connectors' ),
					'type'        => 'text',
					'placeholder' => __( "First Name", 'wp-marketing-automations-connectors' ),
					"class"       => 'bwfan-input-wrapper',
					'tip'         => '',
					"description" => '',
					"required"    => false,
				],
				[
					'id'          => 'last_name',
					'label'       => __( "Last Name", 'wp-marketing-automations-connectors' ),
					'type'        => 'text',
					'placeholder' => __( "Last Name", 'wp-marketing-automations-connectors' ),
					"class"       => 'bwfan-input-wrapper',
					'tip'         => '',
					"description" => '',
					"required"    => false,
				],
			];
		}

		public function get_desc_text( $data ) {
			$data = json_decode( wp_json_encode( $data ), true );
			if ( ! isset( $data['email'] ) || empty( $data['email'] ) ) {
				return '';
			}

			return $data['email'];
		}

	}

	/**
	 * Register this action. Registering the action will make it eligible to see it on single automation screen in select actions dropdown.
	 */
	return 'BWFAN_AC_Create_Contact';
}
