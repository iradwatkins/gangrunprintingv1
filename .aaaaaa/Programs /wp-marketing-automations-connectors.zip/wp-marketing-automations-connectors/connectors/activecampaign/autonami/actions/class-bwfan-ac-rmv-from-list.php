<?php
if ( ! class_exists( 'BWFAN_AC_Rmv_From_List' ) ) {

	#[AllowDynamicProperties]
	final class BWFAN_AC_Rmv_From_List extends BWFAN_Action {

		private static $instance = null;

		private function __construct() {
			$this->action_name     = __( 'Remove Contact From List', 'wp-marketing-automations-connectors' );
			$this->action_desc     = __( 'This action removes a contact from the selected list', 'wp-marketing-automations-connectors' );
			$this->action_priority = 20;
			$this->support_v2      = true;
		}

		public function load_hooks() {
			add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_assets' ), 98 );
		}

		public static function get_instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Localize data for html fields for the current action.
		 */
		public function admin_enqueue_assets() {
			if ( BWFAN_Common::is_load_admin_assets( 'automation' ) ) {
				$data = $this->get_view_data();
				BWFAN_Core()->admin->set_actions_js_data( $this->get_class_slug(), 'list_id_options', $data );
			}
		}

		public function get_view_data() {
			$lists = WFCO_Common::get_single_connector_data( $this->connector, 'lists' );

			return $lists;
		}

		/**
		 * Show the html fields for the current action.
		 */
		public function get_view() {
			$unique_slug = $this->get_slug();
			?>
            <script type="text/html" id="tmpl-action-<?php echo esc_attr__( $unique_slug ); ?>">
                <#
                selected_list_id = (_.has(data.actionSavedData, 'data') && _.has(data.actionSavedData.data, 'list_id')) ? data.actionSavedData.data.list_id : '';
                #>
                <label for="" class="bwfan-label-title">
					<?php
					echo esc_html__( 'Select List', 'wp-marketing-automations-connectors' );
					$message = __( 'Select list to remove contact from and if unable to locate then sync the connector.', 'wp-marketing-automations-connectors' );
					echo $this->add_description( $message, '2xl', 'right' ); //phpcs:ignore WordPress.Security.EscapeOutput
					echo $this->inline_merge_tag_invoke(); //phpcs:ignore WordPress.Security.EscapeOutput
					?>
                </label>
                <select required id="" class="bwfan-input-wrapper bwfan-single-select" name="bwfan[{{data.action_id}}][data][list_id]">
                    <option value=""><?php echo esc_html__( 'Choose A List', 'wp-marketing-automations-connectors' ); ?></option>
                    <#
                    if(_.has(data.actionFieldsOptions, 'list_id_options') && _.isObject(data.actionFieldsOptions.list_id_options) ) {
                    _.each( data.actionFieldsOptions.list_id_options, function( value, key ){
                    selected = (key == selected_list_id) ? 'selected' : '';
                    #>
                    <option value="{{key}}" {{selected}}>{{value}}</option>
                    <# })
                    }
                    #>
                </select>
            </script>
			<?php
		}

		/**
		 * Make all the data which is required by the current action.
		 * This data will be used while executing the task of this action.
		 *
		 * @param $integration_object BWFAN_Integration
		 * @param $task_meta
		 *
		 * @return array|void
		 */
		public function make_data( $integration_object, $task_meta ) {
			$data_to_set            = array();
			$data_to_set['api_key'] = $integration_object->get_settings( 'api_key' );
			$data_to_set['api_url'] = $integration_object->get_settings( 'api_url' );
			$data_to_set['list_id'] = $task_meta['data']['list_id'];
			$data_to_set['email']   = $task_meta['global']['email'];

			return $data_to_set;
		}

		public function make_v2_data( $automation_data, $step_data ) {
			$data_to_set            = array();
			$data_to_set['api_key'] = isset( $step_data['connector_data']['api_key'] ) ? $step_data['connector_data']['api_key'] : '';
			$data_to_set['api_url'] = isset( $step_data['connector_data']['api_url'] ) ? $step_data['connector_data']['api_url'] : '';
			$data_to_set['list_id'] = isset( $step_data['list_id'][0]['id'] ) ? $step_data['list_id'][0]['id'] : 0;
			$data_to_set['email']   = $automation_data['global']['email'];

			return $data_to_set;
		}

		protected function handle_response( $result, $call_object = null ) {
			if ( isset( $result['status'] ) ) {
				return $result;
			}

			if ( isset( $result['body']['subscriber_id'] ) && ! empty( $result['body']['subscriber_id'] ) ) {
				return array(
					'status'  => 3,
					'message' => isset( $result['body']['result_message'] ) ? $result['body']['result_message'] : __( 'Contact successfully removed from list', 'wp-marketing-automations-connectors' ),
				);
			}

			/** in case required field missing */
			if ( ( isset( $result['response'] ) && 502 === absint( $result['response'] ) ) && is_array( $result['body'] ) ) {

				return array(
					'status'  => 4,
					'message' => isset( $result['body'][0] ) ? $result['body'][0] : __( 'Unknown FunnelKit Automations Error', 'wp-marketing-automations-connectors' ),
				);
			}

			$response_code   = sprintf( __( 'Response Code: %s', 'wp-marketing-automations-connectors' ), $result['response'] );
			$result_message  = ( is_array( $result['body'] ) && isset( $result['body']['result_message'] ) ) ? $result['body']['result_message'] : false;
			$message         = ( is_array( $result['body'] ) && isset( $result['body']['message'] ) ) ? $result['body']['message'] : false;
			$unknown_message = __( 'Unknown API Exception', 'wp-marketing-automations-connectors' );

			return array(
				'status'  => 4,
				'message' => ( false !== $result_message ? $result_message : ( false !== $message ? $message : $unknown_message ) ) . $response_code,
			);
		}

		public function handle_response_v2( $result ) {
			$message = __( 'Unknown Error', 'wp-marketing-automations-connectors' );
			if ( ! isset( $result['response'] ) ) {
				$message = isset( $result['message'] ) ? $result['message'] : $message;

				return $this->error_response( $message );
			}

			if ( 502 === absint( $result['response'] ) && is_array( $result['body'] ) ) {
				$message = isset( $result['body'][0] ) ? $result['body'][0] : __( 'Unknown FunnelKit Automations Error', 'wp-marketing-automations-connectors' );
			}

			if ( is_array( $result['body'] ) && isset( $result['body']['errors'] ) ) {
				$message = sprintf( __( 'Error: %s', 'wp-marketing-automations-connectors' ), $result['body']['errors'][0]['title'] );
			}

			if ( 200 !== $result['response'] ) {
				return $this->error_response( $message );
			}

			if ( isset( $result['body']['ecomOrder'] ) && is_array( $result['body']['ecomOrder'] ) && count( $result['body']['ecomOrder'] ) > 0 ) {
				if ( isset( $result['body']['ecomOrder']['orderNumber'] ) && $result['body']['ecomOrder']['id'] ) {
					$order_id = $result['body']['ecomOrder']['orderNumber'];
					$order    = wc_get_order( $order_id );
					if ( $order instanceof WC_Order ) {
						$order->update_meta_data( '_bwfan_ac_create_order_id', $result['body']['ecomOrder']['id'] );
						$order->save();
					}
				}
			}

			$response_code   = __( '. Response Code: ', 'wp-marketing-automations-connectors' ) . $result['response'];
			$result_message  = ( is_array( $result['body'] ) && isset( $result['body']['result_message'] ) ) ? $result['body']['result_message'] : false;
			$message         = ( is_array( $result['body'] ) && isset( $result['body']['message'] ) ) ? $result['body']['message'] : false;
			$unknown_message = __( 'Unknown API Exception', 'wp-marketing-automations-connectors' );

			return $this->success_message( ( false !== $result_message ? $result_message : ( false !== $message ? $message : $unknown_message ) ) . $response_code );
		}

		/**
		 * v2 Method: Get field Schema
		 *
		 * @return array[]
		 */
		public function get_fields_schema() {
			return [
				[
					"id"                  => 'list_id',
					"label"               => __( 'Select List', 'wp-marketing-automations-connectors' ),
					"type"                => 'custom_search',
					'autocompleterOption' => [
						'path'      => 'ac_lists',
						'slug'      => 'ac_lists',
						'labelText' => 'list'
					],
					"allowFreeTextSearch" => false,
					"required"            => true,
					"tip"                 => __( 'Select a list to add contact to and if unable to locate then sync the connector.', 'wp-marketing-automations-connectors' ),
					"multiple"            => false
				]
			];
		}

		public function get_desc_text( $data ) {
			$data = json_decode( wp_json_encode( $data ), true );
			if ( ! isset( $data['list_id'] ) || empty( $data['list_id'] ) ) {
				return '';
			}

			$lists = [];
			foreach ( $data['list_id'] as $list ) {
				if ( ! isset( $list['name'] ) || empty( $list['name'] ) ) {
					continue;
				}
				$lists[] = $list['name'];
			}

			return $lists;
		}
	}

	return 'BWFAN_AC_Rmv_From_List';
}
