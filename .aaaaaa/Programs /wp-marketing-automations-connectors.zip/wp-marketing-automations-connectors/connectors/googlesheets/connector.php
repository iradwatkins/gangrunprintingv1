<?php

if ( ! class_exists( 'BWFCO_Google_Sheets' ) ) {
	#[AllowDynamicProperties]
	class BWFCO_Google_Sheets extends BWF_CO {

		private static $ins = null;
		public $is_setting = true;
		public $v2 = true;

		/** only require for oauth check  */
		public static $oauth_url = 'https://secure-auth.funnelkit.com/google-sheets';
		public $redirect_uri = null; // current application's redirect url
		public static $api_url = 'https://sheets.googleapis.com/v4';

		public function __construct() {
			$this->define_plugin_properties();

			$this->dir               = __DIR__;
			$this->connector_url     = WFCO_AUTONAMI_CONNECTORS_PLUGIN_URL . '/connectors/googlesheets';
			$this->autonami_int_slug = 'BWFAN_Google_Sheets_Integration';
			$this->redirect_uri      = site_url() . '/wp-admin/admin.php';
			$this->priority          = 5;
			add_filter( 'wfco_connectors_loaded', array( $this, 'load_google_sheets' ) );
			add_action( 'current_screen', [ $this, 'save_connector' ] );
		}

		/**
		 * Defining constants
		 */
		public function define_plugin_properties() {
			define( 'WFCO_GS_CLIENT_ID', '415195217844-03pffjmjf3dkc9tvta8agpb2d3i1up38.apps.googleusercontent.com' );
			define( 'WFCO_GS_CLIENT_SECRET', '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' );
			define( 'WFCO_GS_AUTH_URI', 'https://accounts.google.com/o/oauth2/auth' );
			define( 'WFCO_GS_TOKEN_URI', 'https://oauth2.googleapis.com/token' );
		}

		/**
		 * @return BWFCO_Google_Sheets|null
		 */
		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public static function get_headers() {
			return [
				'Authorization' => 'Bearer ' . self::get_access_token(),
				'User-Agent'    => 'FunnelKit',
				'Content-type'  => 'application/json',
				'Accept'        => 'application/json',
			];
		}

		public function load_google_sheets( $available_connectors ) {
			$available_connectors['autonami']['connectors']['bwfco_google_sheets'] = array(
				'name'            => __( 'Google Spread Sheets', 'wp-marketing-automations-connectors' ),
				'desc'            => __( 'Connect with Google Spreadsheets to insert new row or Update any row in a sheet.', 'wp-marketing-automations-connectors' ),
				'connector_class' => 'BWFCO_Google_Sheets',
				'image'           => $this->get_image(),
				'source'          => '',
				'file'            => '',
			);

			return $available_connectors;
		}

		public function save_connector() {
			$code      = filter_input( INPUT_GET, 'gs_token' );
			$connector = filter_input( INPUT_GET, 'wfco_connector' );
			if ( empty( $code ) || empty( $connector ) || ( $this->get_slug() !== $connector ) ) {
				return;
			}

			return $this->handle_settings_form( [ 'gs_token' => $code ], 'save' );
		}

		/**
		 * Handles the settings form submission
		 */

		public function handle_settings_form( $posted_data, $type = 'save' ) {
			$status = 'failed';
			$resp   = array(
				'status'  => $status,
				'id'      => 0,
				'message' => '',
			);

			$connector_data = $this->get_api_data( $posted_data );

			if ( 'failed' === $connector_data['status'] ) {
				BWFAN_Common::log_test_data( $connector_data, 'google-sheet-connector', true );
				$resp['message'] = $connector_data['message'];

				return $resp;
			}
			$resp['status'] = 'success';
			$resp['id']     = WFCO_Common::save_connector_data( $connector_data, $this->get_slug(), 1 );

			wp_redirect( admin_url( 'admin.php?page=autonami&path=/connectors' ) );
			exit;
		}

		public function get_api_data( $posted_data ) {
			$resp_array = array(
				'status'   => 'success',
				'api_data' => array(),
			);

			$resp_array['api_data']['gs_token'] = $posted_data['gs_token'];

			$load_connector = WFCO_Load_Connectors::get_instance();
			$call           = $load_connector->get_call( 'wfco_gs_get_access_token' );
			$call->set_data( [ 'code' => $posted_data['gs_token'] ] );
			$response = $call->process();
			if ( empty( $response['access_token'] ) ) {
				$resp_array['status']  = 'failed';
				$resp_array['message'] = isset( $response['error']['message'] ) ? $response['error']['message'] : '';

				return $resp_array;
			}

			/** Set created time */
			if ( ! isset( $response['created_at'] ) ) {
				$response['created'] = time() - 10;
			}

			$resp_array['api_data']['auth_token'] = is_array( $response ) ? wp_json_encode( $response ) : '';

			return $resp_array;
		}

		/**
		 * @return string|void
		 */
		public static function get_access_token() {
			$connectors_saved = \WFCO_Common::$connectors_saved_data;

			if ( empty( $connectors_saved['bwfco_google_sheets']['api_data']['auth_token'] ) ) {
				return '';
			}

			$connector_id = $connectors_saved['bwfco_google_sheets']['id'];
			$token_data   = json_decode( $connectors_saved['bwfco_google_sheets']['api_data']['auth_token'], true );
			$created      = intval( $token_data['created'] );
			$expires_in   = intval( $token_data['expires_in'] );

			/** If the token is set to expire in the next 30 seconds */
			if ( ( $created + ( $expires_in - 30 ) ) < time() ) {
				$load_connector = WFCO_Load_Connectors::get_instance();
				$call           = $load_connector->get_call( 'wfco_gs_get_refresh_access_token' );
				$call->set_data( [ 'refresh_token' => $token_data['refresh_token'] ] );
				$response = $call->process();

				if ( empty( $response['access_token'] ) ) {
					return $token_data['access_token'];
				}

				/** Set created time */
				if ( empty( $response['created'] ) ) {
					$response['created'] = time() - 10;
				}

				if ( empty( $response['refresh_token'] ) ) {
					$response['refresh_token'] = $token_data['refresh_token'];
				}

				$new_data = [
					'api_data' => [
						'auth_token' => wp_json_encode( $response )
					]
				];
				WFCO_Common::update_connector_data( $new_data, $connector_id );

				return $response['access_token'];
			}

			return $token_data['access_token'];
		}

		/**
		 * Get all worksheets of a particular spreadsheet
		 *
		 * @param $spreadsheet_id
		 *
		 * @return mixed
		 */
		public static function get_google_worksheets( $spreadsheet_id ) {
			$load_connector = WFCO_Load_Connectors::get_instance();
			$worksheet      = $load_connector->get_call( 'wfco_gs_get_worksheets' );
			if ( is_null( $worksheet ) ) {
				return false;
			}

			/**
			 * Set data for worksheet
			 */
			$worksheet->set_data( array(
				'spreadsheet_id' => $spreadsheet_id,
			) );

			return $worksheet->process();
		}

		public function get_fields_schema() {
			$is_connected = isset( WFCO_Common::$connectors_saved_data[ $this->get_slug() ] ) && true === $this->has_settings();

			return array(
				array(
					'id'       => 'gs_token_info',
					'type'     => 'para',
					'class'    => 'bwfan_gs_token_info',
					'required' => false,
					'children' => ! $is_connected ? __( "To connect with googlesheet you need to sign in with Google", 'wp-marketing-automations-connectors' ) : __( 'Already Connected. To reconnect, press the disconnect button and connect again.', 'wp-marketing-automations-connectors' ),
				),
			);
		}

		public function get_settings_fields_values() {
			return [];
		}

		/**
		 * Return the access rights url for the integration where user will be asked for giving rights.
		 *
		 * @return string
		 */
		public function get_access_right_url() {
			$url = WFCO_GS_AUTH_URI . '?access_type=offline&approval_prompt=force&client_id=' . WFCO_GS_CLIENT_ID . '&redirect_uri=' . self::$oauth_url . '&response_type=code&state=' . $this->redirect_uri . '&scope=https://spreadsheets.google.com/feeds';

			return $url;
		}

		public function get_meta_data() {
			return array(
				'connect_type' => 'redirect_url',
				'redirect_url' => $this->get_access_right_url(),
			);
		}
	}

	WFCO_Load_Connectors::register( 'BWFCO_Google_Sheets' );
}
