<?php

namespace WFCO\GoogleSheet;

#[\AllowDynamicProperties]
class Update_Data extends \WFCO_Call {

	private static $instance = null;
	private $range = null;

	public function __construct() {

		$this->required_fields = array( 'spreadsheet_id', 'worksheet_title', 'worksheet_search_data', 'worksheet_data' );
	}

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Get call slug
	 *
	 * @return string
	 */
	public function get_slug() {
		return 'wfco_gs_update_data';
	}

	public function process() {
		$is_required_fields_present = $this->check_fields( $this->data, $this->required_fields );
		if ( false === $is_required_fields_present ) {
			return $this->show_fields_error();
		}

		$load_connector = \WFCO_Load_Connectors::get_instance();
		$call           = $load_connector->get_call( 'wfco_gs_get_sheet_range_value' );
		$call->set_data( $this->data );
		$get_values = $call->process();

		if ( empty( $get_values ) ) {
			/** No row found for the column with value */
			if ( isset( $this->data['enable_insert_row'] ) && 1 === absint( $this->data['enable_insert_row'] ) ) {

				$this->insert_lookup_column_in_data();
				$call = $load_connector->get_call( 'wfco_gs_insert_data' );
				$call->set_data( $this->data );

				return $call->process();
			}

			return array(
				'status'  => 4,
				'message' => __( 'Unable to get any data', 'wp-marketing-automations-connectors' ),
				'skipped' => true
			);
		}
		$lookup_value = $this->data['worksheet_search_data']['value'];
		$get_keys     = [];
		foreach ( $get_values as $key => $value ) {
			if ( empty( $value ) || $lookup_value !== $value[0] ) {
				continue;
			}
			$get_keys[] = $key;
		}

		$update_rows = array_map( function ( $row ) {
			return intval( $row ) + 1;
		}, $get_keys );

		// if update row found then disable for addition of row
		$insert_row = ! empty( $update_rows ) ? false : true;

		/** insert row in case search data not found in column */
		if ( isset( $this->data['enable_insert_row'] ) && 1 === absint( $this->data['enable_insert_row'] ) && true === $insert_row ) {
			/** getting the last row of the sheet to append data properly on sheet */
			$this->insert_lookup_column_in_data();
			$call = $load_connector->get_call( 'wfco_gs_insert_data' );
			$call->set_data( $this->data );

			return $call->process();
		}

		/** If it doesn't found the search row then return */
		if ( empty( $update_rows ) ) {
			return array(
				'status'  => 4,
				'message' => __( 'Unable to find column with value: ' . $this->data['worksheet_search_data']['value'], 'wp-marketing-automations-connectors' ),
				'skipped' => true
			);
		}

		$values = [];
		foreach ( $this->data['worksheet_data'] as $key => $val ) {
			foreach ( $update_rows as $row ) {
				$values[] = array(
					'range'  => $this->data['worksheet_title'] . '!' . $key . $row,
					'values' => array( array( $val ) ),
				);
			}
		}

		if ( empty( $values ) ) {
			return [
				'status'  => 4,
				'message' => __( 'No data to update', 'wp-marketing-automations-connectors' ),
				'skipped' => true
			];
		}

		$params = [
			'valueInputOption' => 'USER_ENTERED',
			'data'             => $values,
		];

		return $this->make_wp_requests( $this->get_endpoint(), wp_json_encode( $params ), \BWFCO_Google_Sheets::get_headers(), \BWF_CO::$POST );
	}


	public function get_endpoint() {
		return \BWFCO_Google_Sheets::$api_url . '/spreadsheets/' . $this->data['spreadsheet_id'] . '/values:batchUpdate';
	}

	public function insert_lookup_column_in_data() {
		if ( ( isset( $this->data['worksheet_search_data']['key'] ) && ! empty( $this->data['worksheet_search_data']['key'] ) ) && ( isset( $this->data['worksheet_search_data']['value'] ) && ! empty( $this->data['worksheet_search_data']['value'] ) ) ) {
			$this->data['worksheet_data'][ $this->data['worksheet_search_data']['key'] ] = $this->data['worksheet_search_data']['value'];
		}
	}

}

return 'WFCO\GoogleSheet\Update_Data';
