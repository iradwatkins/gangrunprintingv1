<?php

namespace WFCO\GoogleSheet;

#[\AllowDynamicProperties]
class Get_Access_Token extends \WFCO_Call {

	private static $instance = null;

	public function __construct() {
		$this->required_fields = array( 'code' );
	}

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Get call slug
	 *
	 * @return string
	 */
	public function get_slug() {
		return 'wfco_gs_get_access_token';
	}

	public function process() {

		$is_required_fields_present = $this->check_fields( $this->data, $this->required_fields );
		if ( false === $is_required_fields_present ) {
			return $this->show_fields_error();
		}

		$data = [
			'client_id'     => WFCO_GS_CLIENT_ID,
			'client_secret' => WFCO_GS_CLIENT_SECRET,
			'grant_type'    => 'authorization_code',
			'redirect_uri'  => \BWFCO_Google_Sheets::$oauth_url,
			'code'          => $this->data['code'],
		];

		$res = $this->make_wp_requests( $this->get_endpoint(), wp_json_encode( $data ), [ 'Content-Type' => 'application/json' ], \BWF_CO::$POST );

		return wp_remote_retrieve_body( $res );
	}

	public function get_endpoint() {
		return WFCO_GS_TOKEN_URI;
	}


}

return 'WFCO\GoogleSheet\Get_Access_Token';
