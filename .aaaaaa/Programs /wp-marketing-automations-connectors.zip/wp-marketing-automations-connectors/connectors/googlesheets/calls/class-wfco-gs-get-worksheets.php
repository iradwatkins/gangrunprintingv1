<?php

namespace WFCO\GoogleSheet;

#[\AllowDynamicProperties]
class Get_Worksheets extends \WFCO_Call {

	private static $instance = null;

	public function __construct() {

		$this->required_fields = array( 'spreadsheet_id' );
	}

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Get call slug
	 *
	 * @return string
	 */
	public function get_slug() {
		return 'wfco_gs_get_worksheets';
	}

	public function process() {
		$is_required_fields_present = $this->check_fields( $this->data, $this->required_fields );
		if ( false === $is_required_fields_present ) {
			return $this->show_fields_error();
		}

		$response = $this->make_wp_requests( $this->get_endpoint(), [], \BWFCO_Google_Sheets::get_headers(), \BWF_CO::$GET );
		$body     = wp_remote_retrieve_body( $response );
		$body     = is_string( $body ) ? json_decode( $body, true ) : $body;
		if ( ! isset( $body['sheets'] ) || empty( $body['sheets'] ) ) {
			$message = isset( $body['message'] ) ? $body['message'] : __( 'No sheets found', 'wp-marketing-automations-connectors' );

			return array( 'status' => 4, 'message' => $message );
		}
		$sheets        = $body['sheets'];
		$worksheets    = array();
		$sheets_column = array();
		foreach ( $sheets as $sheet ) {
			if ( empty( $sheet ) || ! is_array( $sheet ) ) {
				continue;
			}
			$sheet_column_count                             = $sheet['properties']['gridProperties']['columnCount'];
			$sheets_column[ $sheet['properties']['title'] ] = $this->get_sheet_column_details( $sheet_column_count );
			$worksheets[ $sheet['properties']['sheetId'] ]  = $sheet['properties']['title'];
		}

		return array( 'sheets_column' => $sheets_column, 'worksheets' => $worksheets );

	}

	/** getting sheet column details using sheet column count
	 *
	 * @param $number
	 *
	 * @return array
	 */
	public function get_sheet_column_details( $number ) {
		$column_data = array();
		for ( $i = 0; $i <= $number; $i ++ ) {
			$column_name                 = $this->num2alpha( $i );
			$column_data[ $column_name ] = $column_name;
		}

		return $column_data;
	}

	/** converting number to alphabet
	 *
	 * @param $n
	 *
	 * @return string
	 */
	public function num2alpha( $n ) {
		$r = '';
		for ( $i = 1; $n >= 0 && $i < 10; $i ++ ) {
			$r = chr( 0x41 + ( $n % pow( 26, $i ) / pow( 26, $i - 1 ) ) ) . $r;
			$n -= pow( 26, $i );
		}

		return $r;
	}


	public function get_endpoint() {
		return \BWFCO_Google_Sheets::$api_url . '/spreadsheets/' . $this->data['spreadsheet_id'];
	}

}

return 'WFCO\GoogleSheet\Get_Worksheets';
