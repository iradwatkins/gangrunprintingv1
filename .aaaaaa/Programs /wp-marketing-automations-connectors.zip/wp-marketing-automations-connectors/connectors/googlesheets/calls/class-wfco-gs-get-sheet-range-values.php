<?php

namespace WFCO\GoogleSheet;

#[\AllowDynamicProperties]
class Get_Sheet_Range_Values extends \WFCO_Call {

	private static $instance = null;

	private $range = null;

	public function __construct() {

		$this->required_fields = array( 'spreadsheet_id', 'worksheet_title' );
	}

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Get call slug
	 *
	 * @return string
	 */
	public function get_slug() {
		return 'wfco_gs_get_sheet_range_value';
	}

	public function process() {
		$is_required_fields_present = $this->check_fields( $this->data, $this->required_fields );
		if ( false === $is_required_fields_present ) {
			return $this->show_fields_error();
		}
		$search_key  = isset( $this->data['worksheet_search_data']['key'] ) ? $this->data['worksheet_search_data']['key'] : '';
		$this->range = $this->data['worksheet_title'] . '!' . $search_key . '1:' . $search_key;
		if ( ! empty( $this->data['range'] ) ) {
			$this->range = $this->data['range'];
		}

		$res      = $this->make_wp_requests( $this->get_endpoint(), [], \BWFCO_Google_Sheets::get_headers(), \BWF_CO::$GET );
		$res_body = wp_remote_retrieve_body( $res );
		$res_body = is_string( $res_body ) ? json_decode( $res_body, true ) : $res_body;

		return ! empty( $res_body['values'] ) ? $res_body['values'] : [];
	}

	public function get_endpoint() {
		$range = urlencode( $this->range );

		return \BWFCO_Google_Sheets::$api_url . '/spreadsheets/' . $this->data['spreadsheet_id'] . '/values/' . $range;
	}

}

return 'WFCO\GoogleSheet\Get_Sheet_Range_Values';
