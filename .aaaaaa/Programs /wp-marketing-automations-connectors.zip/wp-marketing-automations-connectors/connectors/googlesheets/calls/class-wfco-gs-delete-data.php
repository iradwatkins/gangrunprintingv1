<?php

namespace WFCO\GoogleSheet;

#[\AllowDynamicProperties]
class Delete_Data extends \WFCO_Call {

	private static $instance = null;
	public $range = '';

	public function __construct() {

		$this->required_fields = array( 'spreadsheet_id', 'worksheet_title', 'worksheet_search_data' );
	}

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Get call slug
	 *
	 * @return string
	 */
	public function get_slug() {
		return 'wfco_gs_delete_data';
	}

	public function process() {
		$is_required_fields_present = $this->check_fields( $this->data, $this->required_fields );
		if ( false === $is_required_fields_present ) {
			return $this->show_fields_error();
		}

		$range       = $this->data['worksheet_title'];
		$this->range = $range;

		$this->data['range'] = $range;

		$load_connector = \WFCO_Load_Connectors::get_instance();
		$call           = $load_connector->get_call( 'wfco_gs_get_sheet_range_value' );
		$call->set_data( $this->data );
		$values = $call->process();

		/** If not values found in sheet */
		if ( empty( $values ) ) {
			return array(
				'status'  => 4,
				'message' => __( 'Unable to get any data', 'wp-marketing-automations-connectors' ),
				'skipped' => true
			);
		}

		/** Unset range of get sheet range */
		unset( $this->data['range'] );

		$lookup_value = $this->data['worksheet_search_data']['value'];
		$rows         = [];
		foreach ( $values as $key => $value ) {
			if ( empty( $value ) || ! in_array( $lookup_value, $value, true ) ) {
				continue;
			}
			$rows[ $key ] = $value;
		}

		/** If it doesn't found the search row then return */
		if ( empty( $rows ) ) {
			return array(
				'status'  => 4,
				'message' => __( 'Unable to find column with value: ' . $this->data['worksheet_search_data']['value'], 'wp-marketing-automations-connectors' ),
				'skipped' => true
			);
		}

		$all_columns = isset( $this->data['worksheet_column'] ) && is_array( $this->data['worksheet_column'] ) && count( $this->data['worksheet_column'] ) > 0 ? $this->data['worksheet_column'] : $this->get_all_columns();
		$all_columns = array_keys( $all_columns );

		foreach ( $rows as $key => $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$row_number   = $key + 1;
			$indexes      = array_keys( $row );
			$first_column = $all_columns[ $indexes[0] ];
			$last_column  = $all_columns[ end( $indexes ) ];
			$this->range  = $this->data['worksheet_title'] . '!' . $first_column . $row_number . ':' . $last_column . $row_number;

			$res = $this->make_wp_requests( $this->get_endpoint(), [], \BWFCO_Google_Sheets::get_headers(), \BWF_CO::$POST );
		}

		return $res;
	}

	public function get_endpoint() {
		$range = urlencode( $this->range );

		return \BWFCO_Google_Sheets::$api_url . '/spreadsheets/' . $this->data['spreadsheet_id'] . '/values/' . $range . ':clear';
	}

	public function get_all_columns() {
		return array(
			'A' => 'A',
			'B' => 'B',
			'C' => 'C',
			'D' => 'D',
			'E' => 'E',
			'F' => 'F',
			'G' => 'G',
			'H' => 'H',
			'I' => 'I',
			'J' => 'J',
			'K' => 'K',
			'L' => 'L',
			'M' => 'M',
			'N' => 'N',
			'O' => 'O',
			'P' => 'P',
			'Q' => 'Q',
			'R' => 'R',
			'S' => 'S',
			'T' => 'T',
			'U' => 'U',
			'V' => 'V',
			'W' => 'W',
			'X' => 'X',
			'Y' => 'Y',
			'Z' => 'Z',
		);
	}

}

return 'WFCO\GoogleSheet\Delete_Data';
