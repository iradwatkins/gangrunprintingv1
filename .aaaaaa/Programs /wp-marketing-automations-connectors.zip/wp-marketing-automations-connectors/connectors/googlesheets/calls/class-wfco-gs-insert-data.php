<?php

namespace WFCO\GoogleSheet;

#[\AllowDynamicProperties]
class Insert_Data extends \WFCO_Call {

	private static $instance = null;
	public $range = null;

	public function __construct() {

		$this->required_fields = array( 'spreadsheet_id', 'worksheet_title', 'worksheet_data' );
	}

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Get call slug
	 *
	 * @return string
	 */
	public function get_slug() {
		return 'wfco_gs_insert_data';
	}

	public function process() {
		$is_required_fields_present = $this->check_fields( $this->data, $this->required_fields );
		if ( false === $is_required_fields_present ) {
			return $this->show_fields_error();
		}

		$range               = $this->data['worksheet_title'];
		$this->data['range'] = $range;

		/** getting the last row of the sheet to append data properly on sheet */
		$load_connector = \WFCO_Load_Connectors::get_instance();
		$call           = $load_connector->get_call( 'wfco_gs_get_sheet_range_value' );
		$call->set_data( $this->data );
		$get_values = $call->process();
		/** Unset range of get sheet range */
		unset( $this->data['range'] );

		$last_row   = is_array( $get_values ) ? count( $get_values ) : 0;
		$append_row = $last_row + 1;
		$values     = [];
		foreach ( $this->data['worksheet_data'] as $key => $val ) {
			$values[] = array(
				'range'  => $this->data['worksheet_title'] . '!' . $key . $append_row,
				'values' => array( array( $val ) ),
			);
		}

		if ( empty( $values ) ) {
			return [
				'status'  => 4,
				'message' => __( 'No data to insert', 'wp-marketing-automations-connectors' ),
				'skipped' => true
			];
		}

		$params           = [
			'valueInputOption' => 'USER_ENTERED',
			'data'             => $values,
		];
		$row_limit_exceed = false;
		$res              = $this->make_wp_requests( $this->get_endpoint(), wp_json_encode( $params ), \BWFCO_Google_Sheets::get_headers(), \BWF_CO::$POST );

		/** If sheet rows limit exceed */
		if ( isset( $res['response'] ) && 400 === intval( $res['response'] ) && isset( $res['body']['error']['message'] ) && strpos( $res['body']['error']['message'], 'exceeds grid limits' ) ) {
			$row_limit_exceed = true;
		}

		/** Append row if rows limit exceed */
		if ( $row_limit_exceed ) {
			return $this->insert_row( $append_row );
		}

		return $res;
	}

	public function insert_row( $append_row ) {
		$this->range = $this->data['worksheet_title'] . '!A' . $append_row . ':Z';

		/** earlier using ksort now change it with uksort to sorting the data alphabetically **/
		uksort( $this->data['worksheet_data'], function ( $a, $b ) {
			return $this->alpha2num( $a ) <=> $this->alpha2num( $b );
		} );

		$temp_columns = $this->data['worksheet_data'];
		end( $temp_columns );
		$key           = key( $temp_columns );
		$column_values = array();
		$all_columns   = isset( $this->data['worksheet_column'] ) && is_array( $this->data['worksheet_column'] ) && count( $this->data['worksheet_column'] ) > 0 ? $this->data['worksheet_column'] : \BWFAN_Google_Sheets_Integration::get_a_z_columns_view();
		foreach ( $all_columns as $column ) {
			$column_values[ $column ] = '';
			if ( array_key_exists( $column, $this->data['worksheet_data'] ) ) {
				$column_values[ $column ] = $this->data['worksheet_data'][ $column ];
			}

			if ( $key === $column ) {
				break;
			}
		}

		$first_column = '';
		$values       = [];
		foreach ( $column_values as $key => $col_val ) {
			if ( empty( $first_column ) ) {
				$first_column = $key . $append_row;
			}
			$last_column = $key . $append_row;
			$this->range = $this->data['worksheet_title'] . '!' . $first_column . ':' . $last_column;
			$values[]    = $col_val;
		}
		$params       = [
			'range'          => $this->range,
			'majorDimension' => 'ROWS',
			'values'         => [
				$values
			]
		];
		$range        = urlencode( $this->range );
		$endpoint_url = \BWFCO_Google_Sheets::$api_url . '/spreadsheets/' . $this->data['spreadsheet_id'] . '/values/' . $range . ':append?insertDataOption=INSERT_ROWS&valueInputOption=USER_ENTERED';

		return $this->make_wp_requests( $endpoint_url, wp_json_encode( $params ), \BWFCO_Google_Sheets::get_headers(), \BWF_CO::$POST );
	}

	/**
	 * Converts an alphabetic string into an integer.
	 *
	 * @param $a - This is the number to convert.
	 *
	 * @return float|int
	 */
	public function alpha2num( $a ) {
		$r = 0;
		$l = strlen( $a );
		for ( $i = 0; $i < $l; $i ++ ) {
			$r += pow( 26, $i ) * ( ord( $a[ $l - $i - 1 ] ) - 0x40 );
		}

		return $r - 1;
	}

	public function get_endpoint() {
		return \BWFCO_Google_Sheets::$api_url . '/spreadsheets/' . $this->data['spreadsheet_id'] . '/values:batchUpdate';
	}

}

return 'WFCO\GoogleSheet\Insert_Data';
