<?php

/**
 *
 * Class BWFAN_SendinBlue_Message_Received\
 */
if ( ! class_exists( 'BWFAN_SendinBlue_Message_Received' ) ) {
	final class BWFAN_SendinBlue_Message_Received extends BWFAN_Event {
		private static $instance = null;
		private $sendinblue_id = null;
		private $automation_key = '';
		private $sendinblue_data = array();
		private $email = '';

		private function __construct() {
			$this->optgroup_label         = __( 'Brevo (Formerly Sendinblue )', 'wp-marketing-automations-connectors' );
			$this->event_name             = __( 'Webhook Received', 'wp-marketing-automations-connectors' );
			$this->event_desc             = __( 'This automation would trigger webhook.', 'wp-marketing-automations-connectors' );
			$this->event_merge_tag_groups = array( 'sendinblue_contact' );
			$this->event_rule_groups      = array( 'bwf_contact' );
			$this->customer_email_tag     = '{{sendinblue_contact_email}}';
			$this->v2                     = true;
			$this->support_v1             = false;
			$this->need_unique_key        = true;
		}

		public function load_hooks() {
			add_action( "bwfan_sendinblue_connector_sync_call", array( $this, 'before_process_webhook_contact' ), 10, 3 );
			add_action( 'bwfan_webhook_sendinblue_received', array( $this, 'process' ), 10, 3 );
		}

		public function before_process_webhook_contact( $automation_id, $automation_key, $request_data ) {
			$hook  = 'bwfan_webhook_sendinblue_received';
			$args  = array(
				'sendinblue_data' => $request_data,
				'automation_key'  => $automation_key,
				'automation_id'   => $automation_id
			);
			$group = 'sendinblue';

			if ( bwf_has_action_scheduled( $hook, $args, $group ) ) {
				return;
			}
			bwf_schedule_single_action( time(), $hook, $args, $group );

		}

		public static function get_instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function get_email_event() {

			return isset( $this->sendinblue_data['email'] ) && is_email( $this->sendinblue_data['email'] ) ? $this->sendinblue_data['email'] : false;
		}

		public function get_user_id_event() {

			$email = isset( $this->sendinblue_data['email'] ) && is_email( $this->sendinblue_data['email'] ) ? $this->sendinblue_data['email'] : false;
			$user  = false !== $email ? get_user_by( 'email', $email ) : false;

			return $user instanceof WP_User ? $user->user_email : false;
		}

		public function process( $sendinblue_data, $automation_key, $automation_id ) {
			$this->sendinblue_id  = $automation_id;
			$this->automation_key = $automation_key;

			if ( 'contact_updated' == $sendinblue_data['event'] ) {
				$this->email = $sendinblue_data['content'][0]['email'];
			}

			$this->sendinblue_data = $sendinblue_data;

			$contact_data_v2 = array(
				'sendinblue_id'  => $this->sendinblue_id,
				'automation_key' => $this->automation_key,
				'email'          => $this->email,
				'event'          => $this->get_slug(),
				'version'        => 2
			);

			BWFAN_Common::maybe_run_v2_automations( $this->get_slug(), $contact_data_v2 );
		}

		public function get_event_data() {
			$data_to_send                              = [];
			$data_to_send['global']['sendinblue_id']   = $this->sendinblue_id;
			$data_to_send['global']['automation_key']  = $this->automation_key;
			$data_to_send['global']['sendinblue_data'] = $this->sendinblue_data;
			$data_to_send['global']['email']           = $this->get_email_event();

			return $data_to_send;
		}

		public function set_merge_tags_data( $task_meta ) {
			$merge_data                    = [];
			$merge_data['sendinblue_data'] = $task_meta['global']['sendinblue_data'];
			$merge_data['email']           = $task_meta['global']['email'];
			BWFAN_Merge_Tag_Loader::set_data( $merge_data );
		}

		public function get_fields_schema() {
			return [
				[
					'id'          => 'bwfan_email_map_key',
					'type'        => 'webhook',
					'label'       => __( 'Select Email Field', 'wp-marketing-automations-connectors' ),
					'webhook_url' => rest_url( 'autonami/v1/sendinblue/webhook/' ) . '?sendinblue_id={{automationId}}&sendinblue_key={{uniqueKey}}',
					'required'    => false,
					'hint'        => "",
					'showmap'     => false,
				]
			];
		}

	}

	/**
	 * Register this event to a source.
	 * This will show the current event in dropdown in single automation screen.
	 */
	$saved_connectors = WFCO_Common::$connectors_saved_data;

	if ( empty( $saved_connectors ) ) {
		WFCO_Common::get_connectors_data();
		$saved_connectors = WFCO_Common::$connectors_saved_data;
	}

	if ( array_key_exists( 'bwfco_sendinblue', $saved_connectors ) ) {
		return 'BWFAN_SendinBlue_Message_Received';
	}
}