<?php
if ( ! class_exists( 'BWFAN_SendinBlue_Update_Contact' ) ) {

	final class BWFAN_SendinBlue_Update_Contact extends BWFAN_Action {

		private static $ins = null;

		private function __construct() {
			$this->action_name     = __( 'Update Fields', 'wp-marketing-automations-connectors' );
			$this->action_desc     = __( 'This action adds/ updates the custom fields of the contact', 'wp-marketing-automations-connectors' );
			$this->action_priority = 20;
			$this->support_v2      = true;
			$this->support_v1      = false;
		}

		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_view_data() {
			$attributes = WFCO_Common::get_single_connector_data( $this->connector, 'attributes' );
			if ( empty( $attributes ) ) {
				return array();
			}

			return WFCO_SendinBlue_Common::get_fields_view_data( $attributes );
		}

		public function make_v2_data( $automation_data, $step_data ) {
			$data_to_set            = array();
			$data_to_set['api_key'] = isset( $step_data['connector_data']['api_key'] ) ? $step_data['connector_data']['api_key'] : '';

			$attributes       = WFCO_Common::get_single_connector_data( $this->connector, 'attributes' );
			$fields           = array();
			$fields_value     = array();
			$predefine_fields = isset( $step_data['predefine_fields'] ) ? $step_data['predefine_fields'] : [];
			if ( ! empty( $predefine_fields ) ) {
				$fields       = array_column( $predefine_fields, 'field' );
				$fields_value = array_column( $predefine_fields, 'field_value' );
			}

			$custom_fields       = array();
			$custom_fields_value = array();
			$custom_field_array  = isset( $step_data['custom_fields'] ) ? $step_data['custom_fields'] : [];
			if ( ! empty( $custom_field_array ) ) {
				$custom_fields       = array_column( $custom_field_array, 'field' );
				$custom_fields_value = array_column( $custom_field_array, 'field_value' );
			}

			$contact_fields = array();
			$is_validate    = isset( $step_data['validate_fields'] ) ? $step_data['validate_fields'] : '';

			/** Set Email if global email is empty */
			$data_to_set['email'] = strtolower( $automation_data['global']['email'] );
			if ( empty( $data_to_set['email'] ) ) {
				$user = ! empty( $automation_data['global']['user_id'] ) ? get_user_by( 'ID', $automation_data['global']['user_id'] ) : false;

				$data_to_set['email'] = $user instanceof WP_User ? strtolower( $user->user_email ) : '';
			}

			if ( is_array( $fields ) && ! empty( $fields ) ) {
				foreach ( $fields as $key1 => $field_alias ) {
					if ( 'boolean' === strval( $attributes[ $field_alias ] ) ) {
						$contact_fields[ $field_alias ] = 'Yes' === strval( $fields_value[ $key1 ] ) ? true : false;
						continue;
					}
					$contact_fields[ $field_alias ] = BWFAN_Common::decode_merge_tags( $fields_value[ $key1 ] );
				}
			}

			if ( is_array( $custom_fields ) && ! empty( $custom_fields ) ) {
				foreach ( $custom_fields as $key => $field_alias ) {
					if ( empty( $field_alias ) ) {
						continue;
					}
					$contact_fields[ $field_alias ] = BWFAN_Common::decode_merge_tags( $custom_fields_value[ $key ] );
				}
			}

			/** Filter profile fields to remove blank */
			if ( 1 === intval( $is_validate ) ) {
				foreach ( $contact_fields as $key => $fields ) {
					if ( empty( $fields ) ) {
						unset( $contact_fields[ $key ] );
					}
				}
			}

			$data_to_set['contact_fields'] = $contact_fields;

			return $data_to_set;
		}

		public function handle_response_v2( $result ) {
			if ( is_array( $result ) && isset( $result['status'] ) && 3 === intval( $result['status'] ) ) {
				return $this->success_message( __( $result['message'], 'wp-marketing-automations-connectors' ) );
			}

			if ( is_array( $result ) && isset( $result['status'] ) && 4 === intval( $result['status'] ) ) {
				return $this->error_response( __( $result['message'], 'wp-marketing-automations-connectors' ) );
			}

			$result_message  = ( is_array( $result['body'] ) && isset( $result['body']['message'] ) ) ? $result['body']['message'] : false;
			$unknown_message = __( 'Unknown API Exception', 'wp-marketing-automations-connectors' );

			return $this->error_response( __( false !== $result_message ? $result_message : $unknown_message, 'wp-marketing-automations-connectors' ) );
		}

		/**
		 * v2 Method: Get field Schema
		 *
		 * @return array[]
		 */
		public function get_fields_schema() {
			$predefined_fields = $this->get_view_data();

			return [
				[
					'id'          => 'predefine_fields',
					'type'        => 'repeater',
					'label'       => __( 'Select Custom Fields', 'wp-marketing-automations-connectors' ),
					"fields"      => [
						[
							'id'          => 'field',
							'type'        => 'select',
							'options'     => $predefined_fields,
							'placeholder' => __( 'Select field', 'wp-marketing-automations-connectors' ),
							'label'       => "",
							'tip'         => "",
							"description" => "",
							"required"    => false,
						],
						[
							"id"          => 'field_value',
							"label"       => "",
							"type"        => 'text',
							"class"       => 'bwfan-input-wrapper',
							"description" => "",
							"required"    => false,
						]
					],
					'tip'         => __( "Select available fields to update and if unable to locate then sync the connector.", 'wp-marketing-automations-connectors' ),
					"description" => ""
				],
				[
					'id'          => 'custom_fields',
					'type'        => 'repeater',
					'label'       => __( 'Enter Custom Field Key/ values', 'wp-marketing-automations-connectors' ),
					"fields"      => [
						[
							'id'          => 'field',
							'type'        => 'text',
							'label'       => "",
							'tip'         => "",
							"description" => "",
							"required"    => false,
						],
						[
							"id"          => 'field_value',
							"label"       => "",
							"type"        => 'text',
							"class"       => 'bwfan-input-wrapper',
							"description" => "",
							"required"    => false,
						]
					],
					'tip'         => ( "" ),
					"description" => ""
				],
				[
					'id'            => 'validate_fields',
					'type'          => 'checkbox',
					'label'         => '',
					'checkboxlabel' => __( 'Do not update custom field(s) when passed value is blank', 'wp-marketing-automations-connectors' ),
					"description"   => ""
				]
			];
		}

		public function get_desc_text( $data ) {
			$data = json_decode( wp_json_encode( $data ), true );
			if ( ! isset( $data['custom_fields'] ) || empty( $data['custom_fields'] ) ) {
				return '';
			}

			$count = count( $data['custom_fields'] );

			return ( $count > 1 ) ? $count . ' fields' : $count . ' field';
		}
	}

	/**
	 * Register this action. Registering the action will make it eligible to see it on single automation screen in select actions dropdown.
	 */
	return 'BWFAN_SendinBlue_Update_Contact';
}
