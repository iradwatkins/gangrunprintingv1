<?php
if ( ! class_exists( 'BWFAN_SendinBlue_Add_Contact_To_List' ) ) {
	final class BWFAN_SendinBlue_Add_Contact_To_List extends BWFAN_Action {

		private static $ins = null;

		private function __construct() {
			$this->action_name     = __( 'Add Contact to List', 'wp-marketing-automations-connectors' );
			$this->action_desc     = __( 'This action adds contact to the list', 'wp-marketing-automations-connectors' );
			$this->action_priority = 30;
			$this->support_v2      = true;
			$this->support_v1      = false;
		}

		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function get_view_data() {
			$lists = WFCO_Common::get_single_connector_data( $this->connector, 'lists' );

			return $lists;
		}

		public function make_v2_data( $automation_data, $step_data ) {
			$data_to_set            = array();
			$data_to_set['api_key'] = isset( $step_data['connector_data']['api_key'] ) ? $step_data['connector_data']['api_key'] : '';
			$data_to_set['list_id'] = isset( $step_data['list_id'] ) ? $step_data['list_id'] : '';

			$data_to_set['email'] = isset( $automation_data['global']['email'] ) ? strtolower( $automation_data['global']['email'] ) : '';

			/** Set Email if global email is empty */
			if ( empty( $data_to_set['email'] ) ) {
				$user = ! empty( $automation_data['global']['user_id'] ) ? get_user_by( 'ID', $automation_data['global']['user_id'] ) : false;

				$data_to_set['email'] = $user instanceof WP_User ? strtolower( $user->user_email ) : '';
			}

			return $data_to_set;
		}

		public function handle_response_v2( $result ) {
			if ( is_array( $result ) && isset( $result['status'] ) && 3 === intval( $result['status'] ) ) {
				return $this->success_message( isset( $result['message'] ) ? $result['message'] : __( 'Contact added to list', 'wp-marketing-automations-connectors' ) );
			}

			if ( is_array( $result ) && isset( $result['status'] ) && 4 === intval( $result['status'] ) ) {
				return $this->skipped_response( isset( $result['message'] ) ? $result['message'] : __( 'Contact already in list', 'wp-marketing-automations-connectors' ) );
			}

			$result_message  = ( is_array( $result['body'] ) && isset( $result['body']['message'] ) ) ? $result['body']['message'] : false;
			$unknown_message = __( 'Unknown API Exception', 'wp-marketing-automations-connectors' );

			return $this->error_response( __( false !== $result_message ? $result_message : $unknown_message, 'wp-marketing-automations-connectors' ) );

		}

		public function before_executing_task() {
			add_filter( 'bwfan_current_integration_action', [ $this, 'return_confirmation' ], 10, 1 );
		}

		public function after_executing_task() {
			remove_filter( 'bwfan_current_integration_action', [ $this, 'return_confirmation' ], 10 );
		}

		public function return_confirmation( $bool ) {
			return $this->is_action_tag ? true : $bool;
		}

		/**
		 * v2 Method: Get field Schema
		 *
		 * @return array[]
		 */
		public function get_fields_schema() {
			$lists = BWFAN_PRO_Common::prepared_field_options( array_replace( [ '' => 'Select' ], $this->get_view_data() ) );

			return [
				[
					'id'          => 'list_id',
					'label'       => __( "Select List", 'wp-marketing-automations-connectors' ),
					'type'        => 'select',
					'options'     => $lists,
					'placeholder' => __( 'Choose A List', 'wp-marketing-automations-connectors' ),
					"class"       => 'bwfan-input-wrapper',
					'tip'         => '',
					"description" => '',
					"required"    => true,
				],
			];
		}

		public function get_desc_text( $data ) {
			$data = json_decode( wp_json_encode( $data ), true );
			if ( ! isset( $data['list_id'] ) || empty( $data['list_id'] ) ) {
				return '';
			}

			$sequences = $this->get_view_data();
			if ( ! isset( $sequences[ $data['list_id'] ] ) || empty( $sequences[ $data['list_id'] ] ) ) {
				return '';
			}

			return $sequences[ $data['list_id'] ];
		}
	}

	/**
	 * Register this action. Registering the action will make it eligible to see it on single automation screen in select actions dropdown.
	 */
	return 'BWFAN_SendinBlue_Add_Contact_To_List';
}
