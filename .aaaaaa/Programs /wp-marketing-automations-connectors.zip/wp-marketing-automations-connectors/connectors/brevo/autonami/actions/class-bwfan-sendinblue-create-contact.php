<?php
if ( ! class_exists( 'BWFAN_SendinBlue_Create_Contact' ) ) {

	final class BWFAN_SendinBlue_Create_Contact extends BWFAN_Action {

		private static $instance = null;

		private function __construct() {
			$this->action_name     = __( 'Create Contact', 'wp-marketing-automations-connectors' );
			$this->action_desc     = __( 'This action creates a contact', 'wp-marketing-automations-connectors' );
			$this->action_priority = 10;
			$this->support_v2      = true;
			$this->support_v1      = false;
		}

		public static function get_instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function get_view_data() {
			$attributes = WFCO_Common::get_single_connector_data( $this->connector, 'attributes' );
			if ( empty( $attributes ) ) {
				return array();
			}

			return WFCO_SendinBlue_Common::get_fields_view_data( $attributes );
		}

		public function make_v2_data( $automation_data, $step_data ) {
			$data_to_set            = array();
			$data_to_set['api_key'] = isset( $step_data['connector_data']['api_key'] ) ? $step_data['connector_data']['api_key'] : '';
			$data_to_set['email']   = isset( $step_data['email'] ) ? BWFAN_Common::decode_merge_tags( $step_data['email'] ) : '';

			$attributes       = WFCO_Common::get_single_connector_data( $this->connector, 'attributes' );
			$fields           = array();
			$fields_value     = array();
			$predefine_fields = isset( $step_data['predefine_fields'] ) ? $step_data['predefine_fields'] : [];
			if ( ! empty( $predefine_fields ) ) {
				$fields       = array_column( $predefine_fields, 'field' );
				$fields_value = array_column( $predefine_fields, 'field_value' );
			}

			$contact_fields = array();
			if ( is_array( $fields ) && ! empty( $fields ) ) {
				foreach ( $fields as $key1 => $field_alias ) {
					if ( 'boolean' === strval( $attributes[ $field_alias ] ) ) {
						$contact_fields[ $field_alias ] = 'Yes' === strval( $fields_value[ $key1 ] ) ? true : false;
						continue;
					}
					$contact_fields[ $field_alias ] = BWFAN_Common::decode_merge_tags( $fields_value[ $key1 ] );
				}
			}

			$data_to_set['contact_fields'] = $contact_fields;

			return $data_to_set;
		}

		public function handle_response_v2( $result ) {
			if ( is_array( $result ) && isset( $result['status'] ) && 3 === intval( $result['status'] ) ) {
				return $this->success_message( isset( $result['message'] ) ? $result['message'] : __( 'Contact created ', 'wp-marketing-automations-connectors' ) );
			}

			if ( is_array( $result ) && isset( $result['status'] ) && 4 === intval( $result['status'] ) ) {
				return $this->skipped_response( isset( $result['message'] ) ? $result['message'] : __( ' Contact already exists', 'wp-marketing-automations-connectors' ) );
			}

			$result_message  = ( is_array( $result['body'] ) && isset( $result['body']['message'] ) ) ? $result['body']['message'] : false;
			$unknown_message = __( 'Unknown API Exception', 'wp-marketing-automations-connectors' );

			return $this->error_response( __( false !== $result_message ? $result_message : $unknown_message, 'wp-marketing-automations-connectors' ) );
		}

		/**
		 * v2 Method: Get field Schema
		 *
		 * @return array[]
		 */
		public function get_fields_schema() {
			$predefined_fields = $this->get_view_data();

			return [
				[
					'id'          => 'email',
					'label'       => __( 'Email', 'wp-marketing-automations-connectors' ),
					'type'        => 'text',
					'placeholder' => __( 'Email', 'wp-marketing-automations-connectors' ),
					"class"       => 'bwfan-input-wrapper',
					'tip'         => '',
					"description" => '',
					"required"    => true,
					"errorMsg"    => __( 'Email is required', 'wp-marketing-automations-connectors' ),
				],
				[
					'id'          => 'predefine_fields',
					'type'        => 'repeater',
					'label'       => __( 'Add more contact details', 'wp-marketing-automations-connectors' ),
					"fields"      => [
						[
							'id'          => 'field',
							'type'        => 'select',
							'options'     => $predefined_fields,
							'placeholder' => __( 'Select field', 'wp-marketing-automations-connectors' ),
							'label'       => "",
							'tip'         => "",
							"description" => "",
							"required"    => false,
						],
						[
							"id"          => 'field_value',
							"label"       => "",
							"type"        => 'text',
							"class"       => 'bwfan-input-wrapper',
							"description" => "",
							"required"    => false,
						]
					],
					'tip'         => __( "Select available fields to add and if unable to locate then sync the connector.", 'wp-marketing-automations-connectors' ),
					"description" => ""
				],
			];
		}

		public function get_desc_text( $data ) {
			$data = json_decode( wp_json_encode( $data ), true );
			if ( ! isset( $data['email'] ) || empty( $data['email'] ) ) {
				return '';
			}

			return $data['email'];
		}
	}

	/**
	 * Register this action. Registering the action will make it eligible to see it on single automation screen in select actions dropdown.
	 */
	return 'BWFAN_SendinBlue_Create_Contact';
}
