<?php
if ( ! class_exists( 'BWFCO_SendinBlue' ) ) {
	class BWFCO_SendinBlue extends BWF_CO {

		public static $api_end_point = 'https://api.sendinblue.com/v3/';
		public static $headers = null;
		private static $ins = null;
		public $v2 = true;

		public function __construct() {
			$this->init_brevo();

			/** Connector.php initialization */
			$this->keys_to_track = [
				'api_key',
				'lists',
				'attributes'
			];
			$this->form_req_keys = [
				'api_key',
			];

			$this->sync          = true;
			$this->connector_url = WFCO_AUTONAMI_CONNECTORS_PLUGIN_URL . '/connectors/brevo';
			$this->dir           = __DIR__;
			$this->nice_name     = __( 'Brevo', 'wp-marketing-automations-connectors' );

			$this->autonami_int_slug = 'BWFAN_Brevo_Integration';
			add_filter( 'wfco_connectors_loaded', array( $this, 'add_card' ) );

			/** Facebook Audience uses JSON formatted data as Body */
			add_filter( 'http_request_args', array( $this, 'parse_body_for_brevo' ), 999, 2 );
		}

		public function init_brevo() {
			require __DIR__ . '/includes/class-wfco-brevo-common.php';
			require __DIR__ . '/includes/class-wfco-brevo-call.php';
			require __DIR__ . '/includes/class-wfco-brevo-webhook-setup.php';
		}

		public function parse_body_for_brevo( $args, $url ) {
			if ( empty( $args['body'] ) || false === strpos( $url, 'api.sendinblue' ) ) {
				return $args;
			}
			if ( ! empty( $args['body']['method'] ) ) {
				unset( $args['body']['method'] );

				return $args;
			}
			$args['body'] = wp_json_encode( $args['body'] );

			return $args;
		}

		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public static function get_headers() {
			return self::$headers;
		}

		public static function set_headers( $api_key ) {
			$headers = array(
				'api-key'      => $api_key,
				'Content-Type' => 'application/json',
			);

			self::$headers = $headers;
		}

		/**
		 * This function connects to the automation and fetch the data required for the actions on automations screen to work properly.
		 *
		 * @param $posted_data
		 *
		 * @return array|int
		 */
		public function get_api_data( $posted_data ) {
			$resp_array                        = array();
			$resp_array['api_data']['api_key'] = isset( $posted_data['api_key'] ) ? $posted_data['api_key'] : '';
			$resp_array['status']              = 'success';

			if ( ! isset( $posted_data['api_key'] ) || empty( $posted_data['api_key'] ) ) {
				return $resp_array;
			}

			$params = array(
				'api_key' => $posted_data['api_key']
			);

			/** Fetch Lists */
			$lists_result = $this->fetch_lists( $params );
			if ( is_array( $lists_result ) && count( $lists_result ) > 0 ) {
				$resp_array['api_data']['lists'] = $lists_result;
			}

			$attributes_result = $this->fetch_attributes( $params );
			if ( is_array( $attributes_result ) && count( $attributes_result ) > 0 ) {
				$resp_array['api_data']['attributes'] = $attributes_result;
			}

			return $resp_array;
		}

		/**
		 * Fetch SendinBlue Lists
		 *
		 * @param $params
		 *
		 * @return array
		 */
		public function fetch_lists( $params, $captured_items = [], $offset = 0 ) {
			$connectors = WFCO_Load_Connectors::get_instance();
			/** @var WFCO_SendinBlue_Get_Lists $call */
			$call = $connectors->get_call( 'wfco_sendinblue_get_lists' );
			$call->set_data( $params );
			$result = $call->process();

			if ( 4 === $result['status'] ) {
				wp_send_json( array(
					'status'  => 'failed',
					'message' => isset( $result['message'] ) ? $result['message'] : __( 'Unknown API error', 'wp-marketing-automations-connectors' ),
				) );

				exit;
			}

			$lists = $result['payload']['lists'];
			foreach ( $lists as $list ) {
				$captured_items[ $list['id'] ] = $list['name'];
			}

			$total_lists = $result['payload']['count'];

			$all_lists = $captured_items;
			if ( count( $lists ) > 0 && $total_lists > count( $captured_items ) ) {
				$offset           = $offset + 1;
				$params['offset'] = $offset;

				return $this->fetch_lists( $params, $all_lists, $offset );
			}

			return $all_lists;
		}

		/**
		 * Fetch SendinBlue Contact Attributes
		 *
		 * @param $params
		 *
		 * @return array
		 */
		public function fetch_attributes( $params ) {
			$connectors = WFCO_Load_Connectors::get_instance();
			/** @var WFCO_SendinBlue_Get_List_All_Attributes $call */
			$call = $connectors->get_call( 'wfco_sendinblue_get_list_all_attributes' );
			$call->set_data( $params );
			$result = $call->process();

			if ( 4 === $result['status'] ) {
				wp_send_json( array(
					'status'  => 'failed',
					'message' => isset( $result['message'] ) ? $result['message'] : __( 'Unknown API error', 'wp-marketing-automations-connectors' ),
				) );

				exit;
			}

			$attributes = $result['payload']['attributes'];
			$data       = [];
			foreach ( $attributes as $attribute ) {
				$data[ $attribute['name'] ] = $attribute['type'];
			}

			return $data;
		}


		public function add_card( $available_connectors ) {
			$available_connectors['autonami']['connectors']['bwfco_sendinblue'] = array(
				'name'            => __( 'Brevo ( Formerly SendinBlue )', 'wp-marketing-automations-connectors' ),
				'desc'            => __( 'Add to list, Remove From list and update contact fields.', 'wp-marketing-automations-connectors' ),
				'connector_class' => 'BWFCO_SendinBlue',
				'image'           => $this->get_image(),
				'source'          => '',
				'file'            => '',
			);

			return $available_connectors;
		}

		public function get_fields_schema() {
			return array(
				array(
					'id'          => 'api_key',
					'label'       => __( 'Enter API KEY', 'wp-marketing-automations-connectors' ),
					'type'        => 'text',
					'placeholder' => __( 'Enter API KEY', 'wp-marketing-automations-connectors' ),
					'required'    => true,
					'toggler'     => array(),
				)
			);
		}

		public function get_settings_fields_values() {
			$saved_data = WFCO_Common::$connectors_saved_data;
			$old_data   = ( isset( $saved_data[ $this->get_slug() ] ) && is_array( $saved_data[ $this->get_slug() ] ) && count( $saved_data[ $this->get_slug() ] ) > 0 ) ? $saved_data[ $this->get_slug() ] : array();

			$vals = array();
			if ( isset( $old_data['api_key'] ) ) {
				$vals['api_key'] = $old_data['api_key'];
			}

			return $vals;
		}
	}

	WFCO_Load_Connectors::register( 'BWFCO_SendinBlue' );
}
