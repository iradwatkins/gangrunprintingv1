<?php
if ( ! class_exists( 'WFCO_SendinBlue_Common' ) ) {
	class WFCO_SendinBlue_Common {
		public static function get_fields_view_data( $attributes ) {
			$fields = array();
			foreach ( $attributes as $name => $type ) {
				$hint = '';
				if ( 'boolean' === strval( $type ) ) {
					$hint = __( "Enter one of these options: Yes, No", 'wp-marketing-automations-connectors' );
				}
				$fields[] = [
					'value' => $name,
					'label' => $name,
					'hint'  => $hint,
					'type'  => $type,
				];
			}

			return $fields;
		}
	}
}
