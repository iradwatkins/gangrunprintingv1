<?php
if ( ! class_exists( 'BWFAN_SendinBlue_Webhook_Setup' ) && ! class_exists( 'BWFAN_Brevo_Webhook_Setup' ) ) {
	final class BWFAN_Brevo_Webhook_Setup {
		private static $instance = null;

		private function __construct() {
			add_action( 'rest_api_init', array( $this, 'bwfan_add_webhook_endpoint' ) );
		}

		public static function get_instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function bwfan_add_webhook_endpoint() {
			register_rest_route( 'autonami/v1', '/sendinblue/webhook(?:/(?P<sendinblue_id>\d+))?', array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'bwfan_capture_async_events' ),
				'permission_callback' => '__return_true',
				'args'                => [
					'sendinblue_id'  => array( 'sendinblue_id' => 0 ),
					'sendinblue_key' => array( 'sendinblue_key' => 0 ),
				],
			) );

			register_rest_route( 'autonami/v1', 'sendinblue/webhook(?:/(?P<sendinblue_id>\d+))?', array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'bwfan_capture_async_events' ),
				'permission_callback' => '__return_true',
				'args'                => [
					'sendinblue_id'  => array( 'sendinblue_id' => 0 ),
					'sendinblue_key' => array( 'sendinblue_key' => 0 ),
				],
			) );
		}

		public function bwfan_capture_async_events( WP_REST_Request $request ) {
			$request_params = $request->get_params();

			//check if url parmas is empty or not
			if ( empty( $request_params ) ) {
				$this->responseToBrevo();
			}

			//check request params contain both the key and id
			if ( ( ! isset( $request_params['sendinblue_key'] ) && empty( $request_params['sendinblue_key'] ) ) && ( ! isset( $request_params['sendinblue_id'] ) && empty( $request_params['sendinblue_id'] ) ) ) {
				$this->responseToBrevo();
			}

			//get automation key using automation id
			$automation_id  = $request_params['sendinblue_id'];
			$meta           = BWFAN_Model_Automationmeta::get_meta( $automation_id, 'event_meta' );
			$automation_key = $meta['bwfan_unique_key'];

			//check if the automation key exist in database
			if ( empty( $automation_key ) ) {
				$this->responseToBrevo();
			}

			//validate automation key
			if ( $automation_key !== $request_params['sendinblue_key'] ) {
				$this->responseToBrevo();
			}

			$supported_webhook_types = array( 'contact_updated', 'list_addition' );
			if ( isset( $request_params['event'] ) && in_array( $request_params['event'], $supported_webhook_types, true ) ) {
				do_action( 'bwfan_sendinblue_connector_sync_call', $automation_id, $automation_key, $request_params );
			}
			$this->responseToBrevo();
		}

		public function responseToBrevo() {
			wp_send_json( array( 'status' => __( 'Invalid Brevo webhook request received', 'wp-marketing-automations-connectors' ) ) );
		}
	}

	BWFAN_Brevo_Webhook_Setup::get_instance();
}
