<?php
if ( ! class_exists( 'WFCO_Brevo_Call' ) && ! class_exists( 'Wfco_Brevo_Call' ) ) {

	abstract class WFCO_Brevo_Call extends WFCO_Call {
		/**
		 *
		 * @param array $required_fields
		 */
		public function __construct( $required_fields = array( 'api_key' ) ) {
			$this->required_fields = $required_fields;
		}

		/** Abstract functions that must be present in child's call class */
		abstract function process_brevo_call();

		abstract function get_endpoint( $endpoint_var = '' );

		/** Required fields handling is done here, Also process_brevo_call must be implemented in child call class */
		public function process() {
			$is_required_fields_present = $this->check_fields( $this->data, $this->required_fields );
			if ( false === $is_required_fields_present ) {
				return $this->get_autonami_error( $this->show_fields_error()['body'][0] );
			}

			BWFCO_SendinBlue::set_headers( $this->data['api_key'] );

			return $this->process_brevo_call();
		}

		/**
		 * Use do_sendinblue_call instead of make_wp_requests,
		 * to make use of handling response and errors from remote API call.
		 *
		 * @param array $params
		 * @param int $method
		 * @param string $endpoint_var
		 *
		 * @return array
		 */
		public function do_brevo_call( $params, $method, $endpoint_var = '' ) {
			$response = $this->make_wp_requests( $this->get_endpoint( $endpoint_var ), $params, BWFCO_SendinBlue::get_headers(), $method );

			return $this->handle_api_response( $response );
		}

		public function get_autonami_error( $message = false ) {
			BWFAN_Core()->logger->log( $message, 'failed-' . $this->get_slug() . '-action' );

			return array(
				'status'  => 4,
				'message' => ( false !== $message ) ? $message : __( 'Unknown Autonami Error', 'wp-marketing-automations-connectors' )
			);
		}

		public function get_autonami_success( $message = false ) {
			return array(
				'status'  => 3,
				'message' => ( false !== $message ) ? $message : __( 'Task executed successfully!', 'wp-marketing-automations-connectors' )
			);
		}

		/**
		 * Handle API or Autonami Response or Error
		 *
		 * @param array $res
		 *
		 * @return array
		 */
		public function handle_api_response( $res ) {
			/** If success (within 200 status), then return payload (actual response) and status, message */
			if ( ( absint( $res['response'] ) - 200 ) < 100 ) {
				return array(
					'status'  => 3,
					'payload' => $res['body'],
					'message' => __( 'Brevo API call executed successfully', 'wp-marketing-automations-connectors' )
				);
			}

			/** If failed, send appropriate error */
			$sendinblue_error = '';
			$response_code    = __( '. Error Response Code: ', 'wp-marketing-automations-connectors' ) . $res['response'];
			if ( isset( $res['body']['message'] ) ) {
				$sendinblue_error = __( 'Brevo Error: ', 'wp-marketing-automations-connectors' ) . $res['body']['message'] . ', Code: ' . $res['response'];
			}
			$sendinblue_error = is_array( $res['body'] ) && isset( $res['body']['message'] ) ? $sendinblue_error : false;
			$unknown_error    = __( 'Unknown Brevo Error', 'wp-marketing-automations-connectors' );

			return array(
				'status'  => 4,
				'message' => ( false !== $sendinblue_error ? $sendinblue_error : $unknown_error ) . $response_code,
			);
		}

		public function get_contact_by_email() {
			$params     = [ 'api_key' => $this->data['api_key'], 'email' => $this->data['email'] ];
			$connectors = WFCO_Load_Connectors::get_instance();
			/** @var WFCO_SendinBlue_Get_Contact_By_Email $call */
			$call = $connectors->get_call( 'wfco_sendinblue_get_contact_by_email' );
			$call->set_data( $params );
			$result  = $call->process();
			$contact = [];
			if ( 3 == $result['status'] ) {
				$contact = $result['payload'];
			}

			return $contact;
		}

		public function create_contact() {
			$params = [ 'api_key' => $this->data['api_key'], 'email' => $this->data['email'] ];

			$connectors = WFCO_Load_Connectors::get_instance();
			/** @var WFCO_SendinBlue_Create_Contact $call */
			$call = $connectors->get_call( 'wfco_sendinblue_create_contact' );
			$call->set_data( $params );
			$result = $call->process();

			if ( 3 == $result['status'] ) {
				return $result['payload'];
			} else {
				return $result['message'];
			}
		}

		public function get_all_attributes() {
			$params = [ 'api_key' => $this->data['api_key'] ];

			$connectors = WFCO_Load_Connectors::get_instance();
			/** @var WFCO_SendinBlue_Get_List_All_Attributes $call */
			$call = $connectors->get_call( 'wfco_sendinblue_get_list_all_attributes' );
			$call->set_data( $params );
			$result = $call->process();
			$data   = [];
			if ( 3 == $result['status'] ) {
				$attributes = $result['payload']['attributes'];
				foreach ( $attributes as $attribute ) {
					if ( 'text' != $attribute['type'] ) {
						continue;
					}
					$data[ $attribute['name'] ] = $attribute['name'];
				}
			}

			return $data;
		}

		public function create_custom_attributes( $attribute_name ) {
			$params     = [ 'api_key' => $this->data['api_key'], 'attribute_name' => $attribute_name ];
			$connectors = WFCO_Load_Connectors::get_instance();
			/** @var WFCO_SendinBlue_Create_Custom_Attributes $call */
			$call = $connectors->get_call( 'wfco_sendinblue_create_custom_attributes' );
			$call->set_data( $params );
			$result = $call->process();

			return $result;
		}

		public function add_contact_to_list() {
			$params = [ 'api_key' => $this->data['api_key'], 'email' => $this->data['email'], 'list_id' => $this->data['list_id'] ];

			$connectors = WFCO_Load_Connectors::get_instance();
			/** @var WFCO_SendinBlue_Add_Contact_To_List $call */
			$call = $connectors->get_call( 'wfco_sendinblue_add_contact_to_list' );
			$call->set_data( $params );
			$result = $call->process();

			if ( 3 == $result['status'] ) {
				if ( ! isset( $result['payload'] ) || empty( $result['payload'] ) || ! isset( $result['payload']['contacts'] ) || empty( $result['payload']['contacts'] ) || ! isset( $result['payload']['contacts']['success'] ) || empty( $result['payload']['contacts']['success'] ) ) {
					return array( 'status' => 4, 'message' => __( 'Contact could not be added to list', 'wp-marketing-automations-connectors' ) );
				}

				return array( 'status' => 3, 'message' => __( 'Contact added to list', 'wp-marketing-automations-connectors' ) );
			} else {
				return $result['message'];
			}
		}

		public function update_contact_attributes() {
			if ( empty( $this->data['contact_fields'] ) ) {
				return array();
			}
			$params = [ 'api_key' => $this->data['api_key'], 'email' => $this->data['email'], 'contact_fields' => $this->data['contact_fields'] ];

			$connectors = WFCO_Load_Connectors::get_instance();
			/** @var WFCO_SendinBlue_Update_Contact $call */
			$call = $connectors->get_call( 'wfco_sendinblue_update_contact' );
			$call->set_data( $params );
			$result = $call->process();

			return $result;
		}
	}
}
