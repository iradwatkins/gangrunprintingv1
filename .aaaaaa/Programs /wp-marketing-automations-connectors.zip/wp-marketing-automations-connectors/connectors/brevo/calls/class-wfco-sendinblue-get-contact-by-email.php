<?php
if ( ! class_exists( 'WFCO_SendinBlue_Get_Contact_By_Email' ) ) {
	class WFCO_SendinBlue_Get_Contact_By_Email extends WFCO_Brevo_Call {

		private static $ins = null;

		public function __construct() {
			parent::__construct( [ 'api_key', 'email' ] );
		}

		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function process_brevo_call() {
			if ( ! is_email( $this->data['email'] ) ) {
				return $this->get_autonami_error( __( 'Email is not valid', 'wp-marketing-automations-connectors' ) );
			}

			return $this->do_brevo_call( [], BWF_CO::$GET );
		}

		/**
		 * Return the endpoint.
		 *
		 * @return string
		 */
		public function get_endpoint( $endpoint_var = '' ) {
			return BWFCO_SendinBlue::$api_end_point . 'contacts/' . $this->data['email'];
		}
	}

	return 'WFCO_SendinBlue_Get_Contact_By_Email';
}
