<?php
if ( ! class_exists( 'WFCO_SendinBlue_Get_List_All_Attributes' ) ) {
	class WFCO_SendinBlue_Get_List_All_Attributes extends WFCO_Brevo_Call {

		private static $ins = null;

		public function __construct() {
			parent::__construct( [ 'api_key' ] );
		}

		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function process_brevo_call() {
			return $this->do_brevo_call( [], BWF_CO::$GET );
		}

		/**
		 * Return the endpoint.
		 *
		 * @return string
		 */
		public function get_endpoint( $endpoint_var = '' ) {
			return BWFCO_SendinBlue::$api_end_point . 'contacts/attributes';
		}
	}

	return 'WFCO_SendinBlue_Get_List_All_Attributes';
}
