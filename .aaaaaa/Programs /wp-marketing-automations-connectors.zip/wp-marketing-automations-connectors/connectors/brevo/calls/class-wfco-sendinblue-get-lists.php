<?php
if ( ! class_exists( 'WFCO_SendinBlue_Get_Lists' ) ) {
	class WFCO_SendinBlue_Get_Lists extends WFCO_Brevo_Call {

		private static $ins = null;

		public function __construct() {
			parent::__construct( [ 'api_key' ] );
		}

		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function process_brevo_call() {
			return $this->do_brevo_call( [], BWF_CO::$GET );
		}

		/**
		 * Return the endpoint.
		 *
		 * @return string
		 */
		public function get_endpoint( $endpoint_var = '' ) {
			$offset = ! empty( $this->data['offset'] ) ? $this->data['offset'] : 0;

			return BWFCO_SendinBlue::$api_end_point . 'contacts/lists?limit=10&offset=' . $offset;
		}
	}

	return 'WFCO_SendinBlue_Get_Lists';
}
