<?php
if ( ! class_exists( 'WFCO_SendinBlue_Update_Contact' ) ) {

	class WFCO_SendinBlue_Update_Contact extends WFCO_Brevo_Call {

		private static $ins = null;

		public function __construct() {
			parent::__construct( [ 'api_key', 'email', 'contact_fields' ] );
		}

		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function process_brevo_call() {
			if ( ! is_email( $this->data['email'] ) ) {
				return $this->get_autonami_error( __( 'Email is not valid', 'wp-marketing-automations-connectors' ) );
			}

			$contact = $this->get_contact_by_email();
			if ( empty( $contact ) ) {
				$result = $this->create_contact();

				if ( empty( $result['id'] ) ) {
					return $this->get_autonami_error( $result );
				}
			}

			$update_connector_data = false;
			$saved_data            = WFCO_Common::$connectors_saved_data;
			$old_data              = ( isset( $saved_data['bwfco_sendinblue'] ) && is_array( $saved_data['bwfco_sendinblue'] ) && count( $saved_data['bwfco_sendinblue'] ) > 0 ) ? $saved_data['bwfco_sendinblue'] : array();
			$saved_attributes      = $old_data['attributes'];

			$custom_fields = $this->data['contact_fields'];
			$attributes    = $this->get_all_attributes();
			$fields        = [];
			foreach ( $custom_fields as $key => $value ) {
				$field_name            = strtoupper( $key );
				$fields[ $field_name ] = $value;
				if ( ! in_array( $field_name, $attributes ) ) {
					$result = $this->create_custom_attributes( $field_name );
					if ( 3 != $result['status'] ) {
						continue;
					}
					$saved_attributes[ $field_name ] = $field_name;
					$update_connector_data           = true;
				}
			}

			if ( ! empty( $update_connector_data ) ) {
				$new_data['api_data']['api_key']    = $old_data['api_key'];
				$new_data['api_data']['lists']      = $old_data['lists'];
				$new_data['api_data']['attributes'] = $saved_attributes;
				WFCO_Common::update_connector_data( $new_data['api_data'], $old_data['id'] );
			}
			$params = [ 'attributes' => $fields ];

			return $this->do_brevo_call( $params, BWF_CO::$PUT );
		}

		/**
		 * Return the endpoint.
		 *
		 * @return string
		 */
		public function get_endpoint( $endpoint_var = '' ) {
			return BWFCO_SendinBlue::$api_end_point . 'contacts/' . $this->data['email'];
		}
	}

	return 'WFCO_SendinBlue_Update_Contact';
}
