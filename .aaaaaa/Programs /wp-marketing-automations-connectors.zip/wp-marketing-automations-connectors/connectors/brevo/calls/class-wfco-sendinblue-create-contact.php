<?php
if ( ! class_exists( 'WFCO_SendinBlue_Create_Contact' ) ) {
	class WFCO_SendinBlue_Create_Contact extends WFCO_Brevo_Call {

		private static $ins = null;

		public function __construct() {
			parent::__construct( [ 'api_key', 'email' ] );
		}

		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function process_brevo_call() {
			if ( ! is_email( $this->data['email'] ) ) {
				return $this->get_autonami_error( __( 'Email is not valid.', 'wp-marketing-automations-connectors' ) );
			}
			$params = [ 'email' => $this->data['email'] ];
			if ( isset( $this->data['contact_fields'] ) && ! empty( $this->data['contact_fields'] ) ) {
				$params['attributes'] = $this->data['contact_fields'];
			}

			return $this->do_brevo_call( $params, BWF_CO::$POST );
		}

		/**
		 * Return the endpoint.
		 *
		 * @return string
		 */
		public function get_endpoint( $endpoint_var = '' ) {
			return BWFCO_SendinBlue::$api_end_point . 'contacts';
		}
	}

	return 'WFCO_SendinBlue_Create_Contact';
}
