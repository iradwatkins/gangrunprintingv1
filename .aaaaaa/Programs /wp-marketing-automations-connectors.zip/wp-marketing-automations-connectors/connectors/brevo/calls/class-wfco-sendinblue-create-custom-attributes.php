<?php
if ( ! class_exists( 'WFCO_SendinBlue_Create_Custom_Attributes' ) ) {
	class WFCO_SendinBlue_Create_Custom_Attributes extends WFCO_Brevo_Call {

		private static $ins = null;

		public function __construct() {
			parent::__construct( [ 'api_key', 'attribute_name' ] );
		}

		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function process_brevo_call() {
			$params = [ 'type' => 'text' ];

			return $this->do_brevo_call( $params, BWF_CO::$POST );
		}

		/**
		 * Return the endpoint.
		 *
		 * @return string
		 */
		public function get_endpoint( $endpoint_var = '' ) {
			return BWFCO_SendinBlue::$api_end_point . 'contacts/attributes/normal/' . $this->data['attribute_name'];
		}
	}

	return 'WFCO_SendinBlue_Create_Custom_Attributes';
}
