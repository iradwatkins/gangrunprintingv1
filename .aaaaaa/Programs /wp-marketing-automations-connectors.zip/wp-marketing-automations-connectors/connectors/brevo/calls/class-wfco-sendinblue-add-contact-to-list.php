<?php
if ( ! class_exists( 'WFCO_SendinBlue_Add_Contact_To_List' ) ) {
	class WFCO_SendinBlue_Add_Contact_To_List extends WFCO_Brevo_Call {

		private static $ins = null;

		public function __construct() {
			parent::__construct( [ 'api_key', 'email', 'list_id' ] );
		}

		public static function get_instance() {
			if ( null === self::$ins ) {
				self::$ins = new self();
			}

			return self::$ins;
		}

		public function process_brevo_call() {
			if ( ! is_email( $this->data['email'] ) ) {
				return $this->get_autonami_error( __( 'Email is not valid', 'wp-marketing-automations-connectors' ) );
			}
			$contact = $this->get_contact_by_email();
			if ( empty( $contact ) ) {
				$result = $this->create_contact();
				if ( empty( $result['id'] ) ) {
					return $this->get_autonami_error( $result );
				}
			}
			$params = [ 'emails' => [ $this->data['email'] ] ];

			return $this->do_brevo_call( $params, BWF_CO::$POST );
		}

		/**
		 * Return the endpoint.
		 *
		 * @return string
		 */
		public function get_endpoint( $endpoint_var = '' ) {
			return BWFCO_SendinBlue::$api_end_point . 'contacts/lists/' . $this->data['list_id'] . '/contacts/add';
		}
	}

	return 'WFCO_SendinBlue_Add_Contact_To_List';
}
