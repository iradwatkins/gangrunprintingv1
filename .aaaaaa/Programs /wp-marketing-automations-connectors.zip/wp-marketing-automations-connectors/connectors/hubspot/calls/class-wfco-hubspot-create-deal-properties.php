<?php

namespace WFCO\HubSpot;

#[\AllowDynamicProperties]
class Create_Deal_Property extends WFCO_Hubspot_Call {

	private static $ins = null;

	public function __construct() {
		parent::__construct( array( 'api_key', 'name' ) );
	}

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	/**
	 * Get call slug
	 *
	 * @return string
	 */
	public function get_slug() {
		return 'wfco_hubspot_create_deal_properties';
	}

	public function process_hubspot_call() {

		$params = [
			"name"               => $this->data['name'],
			"label"              => $this->data['label'],
			"description"        => 'This is a custom property for deals. created from FKA',
			"groupName"          => "dealinformation",
			"type"               => "string",
			"fieldType"          => "text",
			"formField"          => "true",
			"readOnlyDefinition" => "False",
			'bwfan_con_source'   => 'autonami',
		];

		\BWFCO_Hubspot::set_headers( $this->data['api_key'] );

		return $this->do_hubspot_call( wp_json_encode( $params ), \BWF_CO::$POST );
	}

	/**
	 * Return the endpoint.
	 *
	 * @return string
	 */
	public function get_endpoint( $endpoint_var = '' ) {
		return \BWFCO_Hubspot::$api_end_point . 'properties/v1/deals/properties';
	}

}

return 'WFCO\HubSpot\Create_Deal_Property';
