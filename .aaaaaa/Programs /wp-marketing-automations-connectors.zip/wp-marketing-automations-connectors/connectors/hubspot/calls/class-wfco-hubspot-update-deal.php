<?php

namespace WFCO\HubSpot;

#[\AllowDynamicProperties]
class Update_Deal extends WFCO_Hubspot_Call {

	private static $ins = null;
	public $deal_id = null;

	public function __construct() {
		parent::__construct( [ 'api_key', 'order_id' ] );
	}

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	/**
	 * Get call slug
	 *
	 * @return string
	 */
	public function get_slug() {
		return 'wfco_hubspot_update_deal';
	}

	public function process_hubspot_call() {
		$order_id = isset( $this->data['order_id'] ) ? $this->data['order_id'] : 0;
		$order    = wc_get_order( $order_id );
		if ( ! $order instanceof \WC_Order ) {
			return $this->get_autonami_error( __( 'Invalid Order', 'wp-marketing-automations-connectors' ) );
		}

		$this->deal_id = $order->get_meta( 'bwfan_hubspot_deal_id' );
		if ( 0 === intval( $this->deal_id ) ) {
			return array(
				'status'  => 'skip',
				'message' => __( 'Deal is not found with this order.', 'wp-marketing-automations-connectors' )
			);
		}
		$deal_name  = isset( $this->data['deal_name'] ) ? $this->data['deal_name'] : '';
		$amount     = isset( $this->data['amount'] ) ? $this->data['amount'] : '';
		$properties = isset( $this->data['properties'] ) ? $this->data['properties'] : [];


		/** Get Deal Id call*/
		$params = [
			"properties"       => [
				"pipeline"  => $this->data['pipeline_id'],
				"dealstage" => $this->data['stage_id'],
				"dealtype"  => $this->data['dealtype'],
			],
			'bwfan_con_source' => 'autonami',
		];
		if ( ! empty( $deal_name ) ) {
			$params['properties']['dealname'] = $deal_name;
		}
		if ( ! empty( $amount ) ) {
			$params['properties']['amount'] = $amount;
		}

		if ( ! empty( $properties ) ) {
			$params['properties'] = array_merge( $params['properties'], $properties );
		}

		\BWFCO_Hubspot::set_headers( $this->data['api_key'] );
		$response = $this->do_hubspot_call( wp_json_encode( $params ), \BWF_CO::$PATCH );
		if ( 4 == $response['status'] ) {
			return $this->get_autonami_error( $response['message'] );
		}

		return $this->get_autonami_success( __( 'Deal updated in Hubspot.', 'wp-marketing-automations-connectors' ) );
	}


	/**
	 * Return the endpoint.
	 *
	 * @return string
	 */
	public function get_endpoint( $endpoint_var = '' ) {
		return \BWFCO_Hubspot::$api_end_point . 'crm/v3/objects/deals/' . $this->deal_id;
	}

	/**
	 * Create deal property
	 *
	 * @return array
	 */
	public function create_deal_property( $name, $label, $connectors ) {
		$params = [
			'api_key' => $this->data['api_key'],
			'name'    => $name,
			'label'   => $label,
		];

		/** @var Create_Deal_Property $call */
		$call = $connectors->get_call( 'wfco_hubspot_create_deal_properties' );
		$call->set_data( $params );
		$respons = $call->process();
		$data    = [];
		if ( isset( $respons['payload']['name'] ) && ! empty( $respons['payload']['name'] ) ) {
			$data[ $respons['payload']['name'] ] = $respons['payload']['label'];
		}

		return $data;
	}

}

return 'WFCO\HubSpot\Update_Deal';
