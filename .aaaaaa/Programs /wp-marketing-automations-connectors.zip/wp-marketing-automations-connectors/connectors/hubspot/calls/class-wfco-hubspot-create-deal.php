<?php

namespace WFCO\HubSpot;

#[\AllowDynamicProperties]
class Create_Deal extends WFCO_Hubspot_Call {

	private static $ins = null;

	public function __construct() {
		parent::__construct( [ 'api_key', 'order_id', 'email', 'deal_name', 'pipeline_id', 'stage_id' ] );
	}

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	/**
	 * Get call slug
	 *
	 * @return string
	 */
	public function get_slug() {
		return 'wfco_hubspot_create_deal';
	}

	public function process_hubspot_call() {

		if ( ! is_email( $this->data['email'] ) ) {
			return $this->get_autonami_error( __( 'Email is not valid', 'wp-marketing-automations-connectors' ) );
		}

		$contact_id = $this->get_contact_by_email();

		if ( empty( $contact_id ) ) {
			$contact = $this->create_contact();
			if ( 4 == $contact['status'] ) {
				return $this->get_autonami_error( $contact['message'] );
			}
			$contact_id = $contact['payload']['id'];
		}


		$order = wc_get_order( $this->data['order_id'] );
		if ( ! $order instanceof \WC_Order ) {
			return $this->get_autonami_error( 'Invalid Order' );
		}

		$deal_id = $order->get_meta( 'bwfan_hubspot_deal_id' );
		if ( intval( $deal_id ) > 0 ) {
			return array(
				'status'  => 'skip',
				'message' => __( 'Deal already created in Hubspot.', 'wp-marketing-automations-connectors' )
			);
		}
		$deal_name         = isset( $this->data['deal_name'] ) ? $this->data['deal_name'] : '';
		$custom_properties = isset( $this->data['properties'] ) ? $this->data['properties'] : [];


		/** Get Deal Id call*/
		$params = [
			"properties"       => [
				"dealname"  => empty( $deal_name ) ? 'order_' . $this->data['order_id'] : $deal_name,
				"amount"    => $order->get_total(),
				"pipeline"  => $this->data['pipeline_id'],
				"dealstage" => $this->data['stage_id'],
			],
			'bwfan_con_source' => 'autonami',
		];

		$connectors = \WFCO_Load_Connectors::get_instance();

		$prepared_custom_properties = [];
		if ( ! empty( $custom_properties ) ) {
			$newly_added = [];
			foreach ( $custom_properties as $name => $value ) {
				$field_id = 'bwf_' . strtolower( str_replace( ' ', '_', $name ) );
				/** Create Deal property if not exist */
				if ( ! in_array( $field_id, array_keys( $this->data['connector_data']['deal_properties'] ), true ) ) {
					$new_propery = $this->create_deal_property( $field_id, $name, $connectors );
					$newly_added = array_merge( $newly_added, $new_propery );
				}
				$prepared_custom_properties[ $field_id ] = $value;
			}

			/** Save in DB if new property created  */
			if ( ! empty( $newly_added ) ) {
				$connector_id = $this->data['connector_data']['id'];
				unset( $this->data['connector_data']['id'] );
				unset( $this->data['connector_data']['last_sync'] );
				unset( $this->data['connector_data']['status'] );
				$deal_properties                                 = $this->data['connector_data']['deal_properties'];
				$deal_properties                                 = array_merge( $deal_properties, $newly_added );
				$this->data['connector_data']['deal_properties'] = $deal_properties;
				\WFCO_Common::update_connector_data( $this->data['connector_data'], $connector_id );
			}

			$params['properties'] = array_merge( $params['properties'], $prepared_custom_properties );
		}
		\BWFCO_Hubspot::set_headers( $this->data['api_key'] );
		$response = $this->do_hubspot_call( wp_json_encode( $params ), \BWF_CO::$POST );

		if ( 4 == $response['status'] ) {
			return $this->get_autonami_error( $response['message'] );
		}
		$deal_id = $response['payload']['id'];

		/** Contact Associate with Deal call*/
		$params = [
			'api_key'          => $this->data['api_key'],
			'from_object_type' => 'contacts',
			'contact_id'       => $contact_id,
			'deal_id'          => $deal_id,
			'bwfan_con_source' => 'autonami',
		];
		$result = $this->associate_with_deal( $params );

		if ( 4 == $result['status'] ) {
			return $this->get_autonami_error( $result['message'] );
		}

		$saved_data    = \WFCO_Common::$connectors_saved_data;
		$old_data      = ( isset( $saved_data['bwfco_hubspot'] ) && is_array( $saved_data['bwfco_hubspot'] ) && count( $saved_data['bwfco_hubspot'] ) > 0 ) ? $saved_data['bwfco_hubspot'] : array();
		$saved_product = ! empty( $old_data['products'] ) ? $old_data['products'] : [];

		$items         = $order->get_items();
		$line_item_ids = [];
		foreach ( $items as $item ) {
			$data  = $item->get_data();
			$name  = $data['name'];
			$price = $data['total'];
			$qty   = $data['quantity'];

			$product_id = array_search( $name, $saved_product );

			$params = [
				'api_key'          => $this->data['api_key'],
				'name'             => $name,
				'bwfan_con_source' => 'autonami',
			];
			if ( empty( $product_id ) ) {
				$product = $this->get_products_by_name( $params, $connectors );

				if ( ! empty( $product ) ) {
					$saved_product[ $product['id'] ] = $product['name'];
					$old_data['products']            = $saved_product;
				} else {
					$params['price'] = $price;
					$product         = $this->create_product( $params, $connectors );

					if ( ! empty( $product ) ) {
						$saved_product[ $product['id'] ] = $product['name'];
						$old_data['products']            = $saved_product;

						$product_id = $product['id'];
					}
				}

				//save new data
				$new_data['api_data']['api_key']  = $old_data['api_key'];
				$new_data['api_data']['products'] = $saved_product;
				$new_data['api_data']['fields']   = $old_data['fields'];
				\WFCO_Common::update_connector_data( $new_data['api_data'], $old_data['id'] );
			}
			$line_item_id = $this->create_line_item( $connectors, $product_id, $qty );
			if ( ! empty( $line_item_id ) ) {
				$line_item_ids[] = $line_item_id;
			}
		}

		/** Line items Associate with Deal */
		$params = [
			'api_key'          => $this->data['api_key'],
			'from_object_type' => 'line_items',
			'line_item_ids'    => $line_item_ids,
			'deal_id'          => $deal_id,
			'bwfan_con_source' => 'autonami',
		];
		$result = $this->associate_with_deal( $params );


		if ( 4 == $result['status'] ) {
			return $this->get_autonami_error( $result['message'] );
		}

		$order->update_meta_data( 'bwfan_hubspot_deal_id', $deal_id );
		$order->save();

		return $this->get_autonami_success( __( 'Deal Created in Hubspot.', 'wp-marketing-automations-connectors' ) );
	}


	/**
	 * Return the endpoint.
	 *
	 * @return string
	 */
	public function get_endpoint( $endpoint_var = '' ) {
		return \BWFCO_Hubspot::$api_end_point . 'crm/v3/objects/deals';
	}

	/**
	 * Create deal property
	 *
	 * @return array
	 */
	public function create_deal_property( $name, $label, $connectors ) {
		$params = [
			'api_key' => $this->data['api_key'],
			'name'    => $name,
			'label'   => $label,
		];

		/** @var Create_Deal_Property $call */
		$call = $connectors->get_call( 'wfco_hubspot_create_deal_properties' );
		$call->set_data( $params );
		$respons = $call->process();
		$data    = [];
		if ( isset( $respons['payload']['name'] ) && ! empty( $respons['payload']['name'] ) ) {
			$data[ $respons['payload']['name'] ] = $respons['payload']['label'];
		}

		return $data;
	}

}

return 'WFCO\HubSpot\Create_Deal';
