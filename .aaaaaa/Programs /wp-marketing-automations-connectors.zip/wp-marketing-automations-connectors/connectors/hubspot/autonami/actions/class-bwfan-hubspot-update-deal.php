<?php

#[AllowDynamicProperties]
final class BWFAN_Hubspot_Update_Deal extends BWFAN_Action {

	private static $ins = null;

	private function __construct() {
		$this->action_name     = __( 'Update Deal', 'wp-marketing-automations-connectors' );
		$this->action_desc     = __( 'This action Updates the deal in Hubspot', 'wp-marketing-automations-connectors' );
		$this->action_priority = 50;
		$this->included_events = array(
			'wc_new_order',
			'wc_product_purchased',
			'wc_order_note_added',
			'wc_order_status_change',
			'wc_order_status_change',
			'wc_product_refunded',
		);
		$this->support_v2      = true;
	}

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	/**
	 * Make all the data which is required by the current action.
	 * This data will be used while executing the task of this action.
	 *
	 * @param $integration_object BWFAN_Integration
	 * @param $task_meta
	 *
	 * @return array|void
	 */
	public function make_data( $integration_object, $task_meta ) {
		$data_to_set            = array();
		$data_to_set['api_key'] = $integration_object->get_settings( 'api_key' );

		/** Set Email if global email is empty */
		$data_to_set['email'] = $task_meta['global']['email'];
		if ( empty( $data_to_set['email'] ) ) {
			$user = ! empty( $task_meta['global']['user_id'] ) ? get_user_by( 'ID', $task_meta['global']['user_id'] ) : false;

			$data_to_set['email'] = $user instanceof WP_User ? $user->user_email : '';
		}

		$data_to_set['order_id'] = $task_meta['global']['order_id'];

		return $data_to_set;
	}

	public function make_v2_data( $automation_data, $step_data ) {
		$data_to_set                   = array();
		$data_to_set['connector_data'] = isset( $step_data['connector_data'] ) ? $step_data['connector_data'] : [];
		$data_to_set['api_key']        = isset( $step_data['connector_data']['api_key'] ) ? $step_data['connector_data']['api_key'] : '';
		$data_to_set['email']          = $automation_data['global']['email'];
		$data_to_set['order_id']       = $automation_data['global']['order_id'];

		$data_to_set['deal_name']   = BWFAN_Common::decode_merge_tags( $step_data['deal_name'] );
		$data_to_set['amount']      = BWFAN_Common::decode_merge_tags( $step_data['amount'] );
		$data_to_set['dealtype']    = isset( $step_data['dealtype'] ) ? $step_data['dealtype'] : '';
		$stage_details              = explode( '_', $step_data['pipeline_stage'] );
		$data_to_set['pipeline_id'] = $stage_details[0];
		$data_to_set['stage_id']    = $stage_details[1];

		/** Set Email if global email is empty */
		if ( empty( $data_to_set['email'] ) ) {
			$user = ! empty( $automation_data['global']['user_id'] ) ? get_user_by( 'ID', $automation_data['global']['user_id'] ) : false;

			$data_to_set['email'] = $user instanceof WP_User ? $user->user_email : '';
		}

		$properties           = isset( $step_data['properties'] ) ? $step_data['properties'] : '';
		$is_validate          = isset( $step_data['validate_fields'] ) ? $step_data['validate_fields'] : '';
		$formatted_properties = [];
		if ( ! empty( $properties ) ) {
			foreach ( $properties as $field ) {
				$value = BWFAN_Common::decode_merge_tags( $field['field_value'] );

				/** If validate setting is enabled  */
				if ( 1 === intval( $is_validate ) && empty( $value ) ) {
					continue;
				}
				$formatted_properties[ $field['field'] ] = $value;
			}
		}
		$data_to_set['properties'] = $formatted_properties;

		return $data_to_set;
	}

	protected function handle_response( $result, $call_object = null ) {
		return $result;
	}

	public function handle_response_v2( $result ) {
		if ( ! isset( $result['status'] ) ) {
			return $this->error_response( __( 'Unknown API Exception', 'wp-marketing-automations-connectors' ) );
		}

		$message = isset( $result['message'] ) ? $result['message'] : __( 'Unknown API Exception', 'wp-marketing-automations-connectors' );
		if ( 4 === absint( $result['status'] ) ) {
			return $this->error_response( $message );
		}

		if ( 'skip' === $result['status'] ) {
			return [
				'status'  => BWFAN_Action::$RESPONSE_SKIPPED,
				'message' => $result['message']
			];
		}

		return $this->success_message( $message );
	}

	/**
	 * v2 Method: Get field Schema
	 *
	 * @return array[]
	 */
	public function get_fields_schema() {
		$data        = $this->get_view_data();
		$deal_stages = $data['pipelines'];
		$properties  = BWFAN_PRO_Common::prepared_field_options( array_replace( [ '' => 'Select' ], $data['properties'] ) );

		$dealtype_options = is_array( $data['property_options'] ) && isset( $data['property_options']['dealtype'] ) ? $data['property_options']['dealtype'] : [];
		$dealtype_options = is_array( $dealtype_options ) ? BWFAN_PRO_Common::prepared_field_options( array_replace( [ '' => '' ], $dealtype_options ) ) : [];

		return [
			[
				'id'          => 'deal_name',
				'label'       => __( "Deal Title", 'wp-marketing-automations-connectors' ),
				'type'        => 'text',
				'placeholder' => __( "Deal Title", 'wp-marketing-automations-connectors' ),
				"class"       => 'bwfan-input-wrapper',
				'tip'         => '',
				"description" => '',
			],
			[
				'id'          => 'amount',
				'label'       => __( "Amount", 'wp-marketing-automations-connectors' ),
				'type'        => 'text',
				'placeholder' => __( "Amount", 'wp-marketing-automations-connectors' ),
				"class"       => 'bwfan-input-wrapper',
				'tip'         => '',
				"description" => '',
			],
			[
				'id'          => 'pipeline_stage',
				'label'       => __( "Select Deal Stage", 'wp-marketing-automations-connectors' ),
				'type'        => 'group_select',
				'options'     => $deal_stages,
				'placeholder' => __( "Choose Deal Stage", 'wp-marketing-automations-connectors' ),
				"class"       => 'bwfan-input-wrapper',
				'tip'         => '',
				"description" => '',
				"required"    => true,
			],
			[
				'id'          => 'dealtype',
				'type'        => 'wp_select',
				'label'       => __( 'Deal Type', 'wp-marketing-automations' ),
				"class"       => 'bwfan-input-wrapper',
				"placeholder" => __( 'Select', 'wp-marketing-automations-connectors' ),
				'options'     => $dealtype_options,
				"required"    => false,
			],
			[
				'id'          => 'properties',
				'type'        => 'repeater',
				'label'       => __( 'Select Custom Properties', 'wp-marketing-automations-connectors' ),
				"fields"      => [
					[
						'id'          => 'field',
						'type'        => 'select',
						'options'     => $properties,
						'placeholder' => __( 'Select field', 'wp-marketing-automations-connectors' ),
						'label'       => "",
						'tip'         => "",
						"description" => "",
						"required"    => false,
					],
					[
						"id"          => 'field_value',
						"label"       => "",
						"type"        => 'text',
						"class"       => 'bwfan-input-wrapper',
						"description" => "",
						"required"    => false,
					]
				],
				'tip'         => __( "", 'wp-marketing-automations-connectors' ),
				"description" => ""
			],
			[
				'id'            => 'validate_fields',
				'type'          => 'checkbox',
				'label'         => '',
				'checkboxlabel' => __( 'Do not update custom Properties when passed value is blank', 'wp-marketing-automations-connectors' ),
				"description"   => ""
			]
		];
	}

	public function get_view_data() {
		$pipelines        = WFCO_Common::get_single_connector_data( $this->connector, 'pipelines' );
		$properties       = WFCO_Common::get_single_connector_data( $this->connector, 'deal_properties' );
		$property_options = WFCO_Common::get_single_connector_data( $this->connector, 'deal_property_options' );

		return [
			'pipelines'        => $pipelines,
			'properties'       => $properties,
			'property_options' => $property_options,
		];
	}

	public function get_action_retry_data() {
		return array(
			MINUTE_IN_SECONDS, // 1 min
			6 * HOUR_IN_SECONDS, // 6 hrs
			18 * HOUR_IN_SECONDS, // 18 hrs
		);
	}

	public function get_default_values() {
		return [
			'dealtype' => '',
		];
	}
}

/**
 * Register this action. Registering the action will make it eligible to see it on single automation screen in select actions dropdown.
 */
return 'BWFAN_Hubspot_Update_Deal';
