<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

#[AllowDynamicProperties]
class BWFAN_Mailchimp_Tags {

	private static $ins = null;

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	public function get_slug() {
		return 'mailchimp_tags';
	}

	public function get_options( $search ) {
		$action = BWFAN_Core()->integration->get_action( 'mailchimp_add_tags' );

		if ( ! $action instanceof BWFAN_Action ) {
			return [];
		}

		return $action->get_options( $search );
	}

}

if ( class_exists( 'BWFAN_Load_Custom_Search' ) ) {
	BWFAN_Load_Custom_Search::register( 'BWFAN_Mailchimp_Tags' );
}

