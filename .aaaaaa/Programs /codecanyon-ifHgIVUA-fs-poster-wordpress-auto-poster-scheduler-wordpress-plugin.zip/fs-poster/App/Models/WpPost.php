<?php

namespace FSPoster\App\Models;

use FSPoster\App\Providers\DB\BlogScope;
use FSPoster\App\Providers\DB\Collection;
use FSPoster\App\Providers\DB\DB;
use FSPoster\App\Providers\DB\Model;
use FSPoster\App\Providers\DB\QueryBuilder;

/**
 * @property int             $id
 * @property int             $blog_id
 * @property int             $wp_post_id
 * @property int             $user_id
 * @property int             $channel_id
 * @property Channel         $channel
 * @property string          $group_id
 * @property string          $customization_data
 * @property-read Collection $customization_data_obj
 * @property string          $send_time
 * @property int             $visit_count
 * @property int             $planner_id
 * @property string          $status = {not_sent, sending, success, error}
 * @property string|null     $error_msg
 * @property string|null     $remote_post_id
 * @property string|null     $data
 * @property Collection      $data_obj
 */
class WpPost extends Model
{
    protected static ?string $tableName = '{wp}_posts';

    public static $relations = [
        'channel' => [ Channel::class, 'id', 'channel_id' ],
    ];

    public static function booted ()
    {
        self::blogBoot();

        self::addGlobalScope( 'my_schedules', function ( QueryBuilder $builder, $queryType )
        {
            if ( $queryType !== 'select' && $queryType !== 'update' && $queryType !== 'delete' )
                return;

            if ( !is_user_logged_in() )
                return;

            $builder->where( function ( $query )
            {
                $query->where( 'channel_id', 'in', Channel::withoutGlobalScope('soft_delete')->select( 'id' ) );
            } );
        } );
    }

}
