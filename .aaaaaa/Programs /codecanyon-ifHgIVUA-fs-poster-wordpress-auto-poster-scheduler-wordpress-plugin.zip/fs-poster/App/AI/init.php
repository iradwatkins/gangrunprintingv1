<?php

defined( 'ABSPATH' ) or exit;

\FSPoster\App\AI\App\Bootstrap::init();