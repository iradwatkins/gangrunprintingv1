<?php

use FSPoster\App\SocialNetworks\Vk\App\Bootstrap;

defined( 'ABSPATH' ) or exit;

Bootstrap::register();