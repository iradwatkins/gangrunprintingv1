<?php

namespace FSPoster\App\SocialNetworks\Xing\Api;

class PostingData
{
    public string $remoteId;
    public string $channelType;

    public string $visibility;
    public string $message;
    public string $link;
    public array $uploadMedia;
}