<?php

use FSPoster\App\SocialNetworks\Xing\App\Bootstrap;

defined( 'ABSPATH' ) or exit;

Bootstrap::register();