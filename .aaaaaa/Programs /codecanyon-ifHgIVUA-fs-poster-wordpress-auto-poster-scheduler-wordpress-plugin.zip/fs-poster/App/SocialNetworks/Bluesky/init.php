<?php

use FSPoster\App\SocialNetworks\Bluesky\App\Bootstrap;

defined( 'ABSPATH' ) or exit;

Bootstrap::register();