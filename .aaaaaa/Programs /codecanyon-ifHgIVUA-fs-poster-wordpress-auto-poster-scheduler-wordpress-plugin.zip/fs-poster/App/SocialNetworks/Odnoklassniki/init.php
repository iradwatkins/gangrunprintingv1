<?php

use FSPoster\App\SocialNetworks\Odnoklassniki\App\Bootstrap;

defined( 'ABSPATH' ) or exit;

Bootstrap::register();