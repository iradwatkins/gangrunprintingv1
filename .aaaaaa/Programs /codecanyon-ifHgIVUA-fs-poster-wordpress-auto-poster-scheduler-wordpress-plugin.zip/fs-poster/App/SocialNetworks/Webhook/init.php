<?php

use FSPoster\App\SocialNetworks\Webhook\App\Bootstrap;

defined( 'ABSPATH' ) or exit;

Bootstrap::register();
