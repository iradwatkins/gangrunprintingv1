<?php

use FSPoster\App\SocialNetworks\Discord\App\Bootstrap;

defined( 'ABSPATH' ) or exit;

Bootstrap::register();