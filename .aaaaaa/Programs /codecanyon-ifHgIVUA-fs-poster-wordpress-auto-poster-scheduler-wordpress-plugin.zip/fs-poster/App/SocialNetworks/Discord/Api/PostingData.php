<?php

namespace FSPoster\App\SocialNetworks\Discord\Api;

class PostingData
{

    public string $channelId;
    public string $message;
	public array $uploadMedia;

}