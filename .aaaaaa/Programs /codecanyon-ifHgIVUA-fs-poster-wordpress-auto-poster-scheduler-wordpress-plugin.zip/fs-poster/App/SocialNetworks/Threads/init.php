<?php

use FSPoster\App\SocialNetworks\Threads\App\Bootstrap;

Bootstrap::register();