<?php

namespace FSPoster\App\SocialNetworks\Threads\Api;

class PostingData
{

    public string $message;
    public string $link;
	public array $uploadMedia;

}