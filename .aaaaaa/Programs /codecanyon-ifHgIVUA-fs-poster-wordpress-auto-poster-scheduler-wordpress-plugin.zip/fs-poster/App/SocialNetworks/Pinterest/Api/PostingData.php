<?php

namespace FSPoster\App\SocialNetworks\Pinterest\Api;

class PostingData
{

	public string $boardId;
    public string $title;
    public string $message;
    public string $link;
    public string $altText;
	public array $uploadMedia;

}