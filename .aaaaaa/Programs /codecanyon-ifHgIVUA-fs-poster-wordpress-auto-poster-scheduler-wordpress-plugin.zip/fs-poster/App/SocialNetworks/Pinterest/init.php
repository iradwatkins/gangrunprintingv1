<?php

use FSPoster\App\SocialNetworks\Pinterest\App\Bootstrap;

defined( 'ABSPATH' ) or exit;

Bootstrap::register();