<?php

use FSPoster\App\SocialNetworks\Instagram\App\Bootstrap;

defined( 'ABSPATH' ) or exit;

Bootstrap::register();