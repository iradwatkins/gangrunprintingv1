<?php

use FSPoster\App\SocialNetworks\Reddit\App\Bootstrap;

defined( 'ABSPATH' ) or exit;

Bootstrap::register();