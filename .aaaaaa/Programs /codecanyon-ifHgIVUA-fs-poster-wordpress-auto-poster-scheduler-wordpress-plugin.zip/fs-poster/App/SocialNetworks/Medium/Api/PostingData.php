<?php

namespace FSPoster\App\SocialNetworks\Medium\Api;

class PostingData
{

    public string $channelId;
    public string $channelType;
    public string $title;
    public string $message;
    public array $tags;

}