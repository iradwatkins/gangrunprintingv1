<?php

use FSPoster\App\SocialNetworks\Medium\App\Bootstrap;

defined( 'ABSPATH' ) or exit;

Bootstrap::register();