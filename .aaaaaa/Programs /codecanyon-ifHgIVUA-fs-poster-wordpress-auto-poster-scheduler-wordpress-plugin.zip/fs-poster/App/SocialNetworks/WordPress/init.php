<?php

use FSPoster\App\SocialNetworks\WordPress\App\Bootstrap;

defined( 'ABSPATH' ) or exit;

Bootstrap::register();