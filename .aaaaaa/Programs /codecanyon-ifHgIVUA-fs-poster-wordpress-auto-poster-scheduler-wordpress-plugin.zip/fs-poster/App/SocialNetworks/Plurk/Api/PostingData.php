<?php

namespace FSPoster\App\SocialNetworks\Plurk\Api;

class PostingData
{

    public string $message;
    public string $link;
	public string $qualifier;
	public array  $uploadMedia;

}