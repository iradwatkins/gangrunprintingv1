<?php

use FSPoster\App\SocialNetworks\Plurk\App\Bootstrap;

defined( 'ABSPATH' ) or exit;

Bootstrap::register();