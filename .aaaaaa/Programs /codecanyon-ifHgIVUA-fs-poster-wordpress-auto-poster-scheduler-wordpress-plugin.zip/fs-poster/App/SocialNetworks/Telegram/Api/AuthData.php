<?php

namespace FSPoster\App\SocialNetworks\Telegram\Api;

class AuthData
{

    public string $token;
    public string $chatId;

}