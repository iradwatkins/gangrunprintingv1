<?php

use FSPoster\App\SocialNetworks\Telegram\App\Bootstrap;

defined( 'ABSPATH' ) or exit;

Bootstrap::register();