<?php

use FSPoster\App\SocialNetworks\Blogger\App\Bootstrap;

defined( 'ABSPATH' ) or exit;

Bootstrap::register();