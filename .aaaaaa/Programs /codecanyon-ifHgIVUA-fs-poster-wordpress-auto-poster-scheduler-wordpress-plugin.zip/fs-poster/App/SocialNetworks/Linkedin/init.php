<?php

use FSPoster\App\SocialNetworks\Linkedin\App\Bootstrap;

defined( 'ABSPATH' ) or exit;

Bootstrap::register();