<?php

namespace FSPoster\App\SocialNetworks\Linkedin\Api;

class PostingData
{

	public string $channelId;
	public string $channelType;
    public string $message;
    public string $link;
	public array $uploadMedia;

}