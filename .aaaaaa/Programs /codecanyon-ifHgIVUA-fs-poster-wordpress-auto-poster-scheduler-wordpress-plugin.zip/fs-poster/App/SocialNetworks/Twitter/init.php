<?php

use FSPoster\App\SocialNetworks\Twitter\App\Bootstrap;

defined( 'ABSPATH' ) or exit;

Bootstrap::register();