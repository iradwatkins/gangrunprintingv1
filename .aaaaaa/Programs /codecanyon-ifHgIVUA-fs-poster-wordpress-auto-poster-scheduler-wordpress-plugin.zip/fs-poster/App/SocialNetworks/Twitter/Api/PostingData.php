<?php

namespace FSPoster\App\SocialNetworks\Twitter\Api;

class PostingData
{

    public string $message;
    public string $link;
	public array $uploadMedia;
	public string $firstComment;

}