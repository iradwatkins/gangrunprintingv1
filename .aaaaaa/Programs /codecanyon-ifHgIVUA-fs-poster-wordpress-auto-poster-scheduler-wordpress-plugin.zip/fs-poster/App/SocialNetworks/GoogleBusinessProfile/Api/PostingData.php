<?php

namespace FSPoster\App\SocialNetworks\GoogleBusinessProfile\Api;

class PostingData
{

    public string $message;
    public string $link;
    public string $linkType;
    public string $accountId;
    public string $locationId;
	public array $uploadMedia;

}