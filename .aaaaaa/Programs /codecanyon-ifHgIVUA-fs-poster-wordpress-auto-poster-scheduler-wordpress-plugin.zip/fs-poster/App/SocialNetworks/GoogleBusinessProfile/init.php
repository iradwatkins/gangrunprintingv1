<?php

use FSPoster\App\SocialNetworks\GoogleBusinessProfile\App\Bootstrap;

defined( 'ABSPATH' ) or exit;

Bootstrap::register();