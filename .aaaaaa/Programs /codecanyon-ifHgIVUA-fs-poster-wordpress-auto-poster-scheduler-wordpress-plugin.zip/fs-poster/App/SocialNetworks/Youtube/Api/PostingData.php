<?php

namespace FSPoster\App\SocialNetworks\Youtube\Api;

class PostingData
{

    public string $message;
	public array  $uploadMedia;

}