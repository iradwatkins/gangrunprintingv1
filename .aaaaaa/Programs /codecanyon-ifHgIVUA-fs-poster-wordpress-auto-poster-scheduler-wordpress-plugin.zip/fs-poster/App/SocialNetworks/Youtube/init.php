<?php

use FSPoster\App\SocialNetworks\Youtube\App\Bootstrap;

defined( 'ABSPATH' ) or exit;

Bootstrap::register();