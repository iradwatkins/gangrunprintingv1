<?php

use FSPoster\App\SocialNetworks\Tumblr\App\Bootstrap;

defined( 'ABSPATH' ) or exit;

Bootstrap::register();