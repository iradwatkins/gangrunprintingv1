<?php

namespace FSPoster\App\SocialNetworks\Tumblr\Api;

class TumblrBlog
{
    public string $name;
    public string $title;
}