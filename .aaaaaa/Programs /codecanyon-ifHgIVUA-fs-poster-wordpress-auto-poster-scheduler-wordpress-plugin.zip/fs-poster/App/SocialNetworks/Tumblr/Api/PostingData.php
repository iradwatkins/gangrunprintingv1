<?php

namespace FSPoster\App\SocialNetworks\Tumblr\Api;

class PostingData
{

    public string $blogId;
    public string $title;
    public string $message;
    public array $tags;
    public array $uploadMedia;
	public string $link;

}