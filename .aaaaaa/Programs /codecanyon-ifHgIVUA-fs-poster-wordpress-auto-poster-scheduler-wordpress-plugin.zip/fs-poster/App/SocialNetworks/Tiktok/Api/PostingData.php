<?php

namespace FSPoster\App\SocialNetworks\Tiktok\Api;

class PostingData
{

    public string $title;
    public string $description;
	public array  $uploadMedia;
	public string $privacyLevel;
	public bool $disableDuet;
	public bool $disableComment;
	public bool $disableStitch;
	public bool $autoAddMusicToPhoto;
    public string $promotionalContentType;

}