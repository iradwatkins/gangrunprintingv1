<?php

use FSPoster\App\SocialNetworks\Tiktok\App\Bootstrap;

defined( 'ABSPATH' ) or exit;

Bootstrap::register();