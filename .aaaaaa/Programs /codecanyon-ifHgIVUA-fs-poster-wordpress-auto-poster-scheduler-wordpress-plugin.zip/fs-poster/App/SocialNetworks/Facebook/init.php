<?php

use FSPoster\App\SocialNetworks\Facebook\App\Bootstrap;

defined( 'ABSPATH' ) or exit;

Bootstrap::register();