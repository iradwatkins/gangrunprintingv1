<?php

namespace FSPoster\App\SocialNetworks\Mastodon\Api;

class PostingData
{

    public string $message;
    public string $link;
	public array $uploadMedia;

}