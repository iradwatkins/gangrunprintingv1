<?php

use FSPoster\App\SocialNetworks\Mastodon\App\Bootstrap;

defined( 'ABSPATH' ) or exit;

Bootstrap::register();