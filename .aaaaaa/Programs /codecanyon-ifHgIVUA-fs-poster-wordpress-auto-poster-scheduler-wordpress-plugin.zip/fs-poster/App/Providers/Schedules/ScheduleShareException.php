<?php

namespace FSPoster\App\Providers\Schedules;

class ScheduleShareException extends \Exception
{

}