<?php

namespace FSPoster\App\Providers\Schedules;

class SocialNetworkApiException extends \Exception
{

}