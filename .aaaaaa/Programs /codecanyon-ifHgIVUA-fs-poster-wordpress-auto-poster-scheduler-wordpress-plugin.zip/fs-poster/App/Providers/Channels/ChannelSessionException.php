<?php

namespace FSPoster\App\Providers\Channels;

class ChannelSessionException extends \Exception
{

}