=== WooCommerce Order Status Manager ===
Author: skyverge
Tags: woocommerce
Requires at least: 5.6
Tested up to: 6.8.1
Requires PHP: 7.4
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Easily create custom order statuses and trigger custom emails when order status changes

See https://docs.woocommerce.com/document/woocommerce-order-status-manager/ for full documentation.

== Installation ==

1. Upload the entire 'wocoommerce-order-status-manager' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
