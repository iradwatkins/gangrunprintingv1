<?php 
class WCOD_Shortcode
{
	public function __construct()
	{
		add_shortcode( 'wcod_order_details', array(&$this, 'render_order_details' ));
	}
	public function render_order_details($atts)
	{
		
		$parameters = shortcode_atts( array(
        'id' => null,
			), $atts );
			
		$order_id = $parameters['id'] ? $parameters['id'] : false;
		$wc_order = $order_id ? wc_get_order($order_id) : false;
		if(@is_admin())
			return; 
		
		global $wcod_option_model, $wcod_html_model;
		$my_unique_id = rand(1111, 999999);
		wp_register_script("wcod-shortcode-load-order", WCOD_PLUGIN_PATH."/js/frontend/shortcode-load-order.js", array('jquery'));
		wp_localize_script( 'wcod-shortcode-load-order', 'wcod_data', array(
																'no_valid_order_id_msg' => __( 'Please insert a valid order id!', 'woocommerce-order-details' ),	
																'loading_msg' => __( 'Loading, please wait...', 'woocommerce-order-details' ),	
																'ajaxurl' => admin_url( 'admin-ajax.php' )
																) );
		wp_enqueue_script( 'wcod-shortcode-load-order' );
		wp_enqueue_style("wcod-shortcode-load-order", WCOD_PLUGIN_PATH."/css/frontend/shortcode-load-order.css");
		
		//needed to make table work
		wp_register_script("wcod-frontend-orders-page", WCOD_PLUGIN_PATH."/js/frontend/orders-page.js", array('jquery'));
		$js_options = array(
			'arrow_color' => $wcod_option_model->get_options('arrow_color', "")
		);
		wp_localize_script( 'wcod-frontend-orders-page', 'wcod_settings', $js_options );
		wp_enqueue_script( 'wcod-frontend-orders-page' );
		
		wp_enqueue_script("wcod-frontend-svg", WCOD_PLUGIN_PATH."/js/vendor/svg/jquery.svgInject.js", array('jquery'));
		wp_enqueue_style("wcod-frontend-orders-page", WCOD_PLUGIN_PATH."/css/frontend/orders-page.css");
		ob_start();
		if(!$wc_order): ?>
		<div class="wcod_loader_controllers_conainer" id="wcod_loader_controllers_conainer_<?php echo $my_unique_id; ?>">
			<input type="text" value="" class="wcod_load_order_details_input" id="wcod_order_id_<?php echo $my_unique_id; ?>"></input>
			<button class="button wcod_load_order_details_button" data-id="<?php echo $my_unique_id; ?>"><?php _e('View', 'woocommerce-order-details') ?></button>
		</div>
		<?php endif; ?>
		<div class="wcod_order_details_conainer" id="wcod_order_details_conainer_<?php echo $my_unique_id; ?>">
		<?php if($wc_order)
		{
				$wcod_html_model->render_order_table($wc_order, true);
		}
		?>
		</div>
		<?php

		return ob_get_clean();		
	}
}
?>