jQuery(document).ready(function($)
{
    $('.wcod_color_picker').wpColorPicker();
});